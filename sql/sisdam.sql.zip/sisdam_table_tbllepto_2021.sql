
-- --------------------------------------------------------

--
-- Estrutura da tabela `tbllepto_2021`
--

CREATE TABLE `tbllepto_2021` (
  `DataEntrada` varchar(10) DEFAULT NULL,
  `nDoc` varchar(7) NOT NULL,
  `NomeSolicitante` varchar(43) DEFAULT NULL,
  `TelefoneFixo` varchar(9) DEFAULT NULL,
  `Ddd` varchar(4) NOT NULL DEFAULT '(11)',
  `Da` varchar(2) DEFAULT NULL,
  `Setor1` varchar(4) DEFAULT NULL,
  `Cep1` varchar(9) DEFAULT NULL,
  `Logradouro` varchar(15) DEFAULT NULL,
  `Endereco1` varchar(83) DEFAULT NULL,
  `N` varchar(6) DEFAULT NULL,
  `Complemento` varchar(30) DEFAULT NULL,
  `Bairro1` varchar(30) DEFAULT NULL,
  `UBS1` varchar(33) DEFAULT NULL,
  `PgGuia1` varchar(7) DEFAULT NULL,
  `Observacoes` varchar(239) DEFAULT NULL,
  `DataBloqueio` varchar(10) DEFAULT NULL,
  `DataNeb` varchar(10) DEFAULT NULL,
  `Data1Sintomas` varchar(10) DEFAULT NULL,
  `Se1Sintomas` varchar(6) DEFAULT NULL,
  `DataColeta` varchar(13) DEFAULT NULL,
  `DataResultado` varchar(10) DEFAULT NULL,
  `Resultado` varchar(23) DEFAULT NULL,
  `ResultadoNs1` varchar(19) DEFAULT NULL,
  `AutoctoneImportado` varchar(12) DEFAULT NULL,
  `Fechamento` varchar(10) DEFAULT NULL,
  `LPICidade` varchar(12) DEFAULT NULL,
  `LpiEstado` varchar(12) DEFAULT NULL,
  `DataNotificacao` varchar(10) DEFAULT NULL,
  `UnidadeNotificadora` varchar(60) DEFAULT NULL,
  `SeDataNotificacao` varchar(6) DEFAULT NULL,
  `usuarioExame` varchar(13) DEFAULT NULL,
  `DataAlteracaoExame` varchar(10) DEFAULT NULL,
  `usuarioAlteracao` varchar(13) DEFAULT NULL,
  `DataAlteracao` datetime DEFAULT current_timestamp(),
  `Sexo` varchar(1) DEFAULT NULL,
  `DataNascimento` varchar(10) DEFAULT NULL,
  `usuarioLer` varchar(13) DEFAULT NULL,
  `DataLer` varchar(19) DEFAULT NULL,
  `Impressao` varchar(2) DEFAULT '0',
  `DataObito` varchar(10) DEFAULT NULL,
  `CnesUnidadeNotificadora` varchar(7) DEFAULT NULL,
  `Latitude` varchar(10) DEFAULT NULL,
  `Longitude` varchar(19) DEFAULT NULL,
  `RuaGoogle` varchar(103) DEFAULT NULL,
  `Status` varchar(10) DEFAULT NULL,
  `Descarte` varchar(2) DEFAULT '0',
  `idRua` varchar(4) DEFAULT NULL,
  `agravo` varchar(20) NOT NULL DEFAULT 'LEPTOSPIROSE',
  `ResultadoTr` varchar(20) NOT NULL DEFAULT 'Exame Nao Realizado'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `tbllepto_2021`
--

INSERT INTO `tbllepto_2021` (`DataEntrada`, `nDoc`, `NomeSolicitante`, `TelefoneFixo`, `Ddd`, `Da`, `Setor1`, `Cep1`, `Logradouro`, `Endereco1`, `N`, `Complemento`, `Bairro1`, `UBS1`, `PgGuia1`, `Observacoes`, `DataBloqueio`, `DataNeb`, `Data1Sintomas`, `Se1Sintomas`, `DataColeta`, `DataResultado`, `Resultado`, `ResultadoNs1`, `AutoctoneImportado`, `Fechamento`, `LPICidade`, `LpiEstado`, `DataNotificacao`, `UnidadeNotificadora`, `SeDataNotificacao`, `usuarioExame`, `DataAlteracaoExame`, `usuarioAlteracao`, `DataAlteracao`, `Sexo`, `DataNascimento`, `usuarioLer`, `DataLer`, `Impressao`, `DataObito`, `CnesUnidadeNotificadora`, `Latitude`, `Longitude`, `RuaGoogle`, `Status`, `Descarte`, `idRua`, `agravo`, `ResultadoTr`) VALUES
('17/05/2021', '5602940', 'MARCIETE PANTAJO ALMEIDA', '977789855', '11', '83', '8303', '02323-000', 'RUA', 'USHIKICHI KAMIYA (DO 1061 AO FIM LADO PAR E IMPAR) *', '1154', '', 'JARDIM FONTALIS', 'UBS V NOVA GALVAO', '15-S03', NULL, NULL, NULL, '31/03/2021', '202113', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '10/05/2021', 'HOSP SAO LUIZ GONZAGA', '202119', NULL, NULL, 'D790072', '2021-05-17 08:56:20', NULL, '01/02/1980', NULL, NULL, '0', NULL, '2076896', '-23.438659', '-46.5862189', 'Rua Ushikichi Kamiya, 1154 - Jardim Fontalis, São Paulo - SP, 02323-000, Brazil', NULL, '0', '1764', 'LEPTOSPIROSE', 'Exame Nao Realizado'),
('19/01/2021', '7215600', 'ADEILTON DA SILVA', '987653959', '11', '38', '3805', '02230-040', 'RUA', 'BAIA DE SANTA CLARA', '545', '', 'EDU CHAVES', 'UBS PQ EDU CHAVES', '72-M03', NULL, '19/01/2021', NULL, '30/12/2020', '202053', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '05/01/2021', 'HOSP MUN VER JOSE STOROPOLLI', '202101', NULL, NULL, 'D790072', '2021-01-19 07:43:07', NULL, '29/08/1965', 'D790072', '2021-01-19 07:43:36', '1', NULL, '3212130', '-23.482664', '-46.56161119999999', 'Rua Baía de Santa Clara, 545 - Parque Edu Chaves, São Paulo - SP, 02230-040, Brazil', NULL, '0', '310', 'LEPTOSPIROSE', 'Exame Nao Realizado'),
('12/08/2021', '7239771', 'REFERE JOSE ADAUTO SILVA CALDAS', '947369723', '11', '83', '8307', '02318-020', 'RUA', 'MANUEL VIEIRA DA LUZ', '59', '', 'SITIO DO PIQUERI', 'UBS JOVA RURAL', '14-V18', NULL, NULL, NULL, '09/07/2021', '202127', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '16/07/2021', 'HOSP SAO LUIZ GONZAGA', '202128', NULL, NULL, 'D790072', '2021-08-12 08:37:39', NULL, '02/04/1961', NULL, NULL, '0', NULL, '2076896', '-23.449876', '-46.5882894', 'Rua Manuel Viêira da Luz, 59 - Jardim Jacana, São Paulo - SP, Brasil', NULL, '0', '1199', 'LEPTOSPIROSE', 'Exame Nao Realizado'),
('08/09/2021', '7240037', 'MANOEL JOSE SANTOS', '990094164', '11', '83', '8309', '02321-160', 'RUA', 'RIBEIRO DE VASCONCELOS', '28', '', 'JD. MIGUEL MAURICIO', 'UBS J JOAMAR', '14-R16', NULL, '08/09/2021', NULL, '23/08/2021', '202134', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '30/08/2021', 'HOSP SAO LUIZ GONZAGA', '202135', NULL, NULL, 'D790072', '2021-09-08 09:08:59', NULL, '03/05/1949', 'D790072', '2021-09-08 09:09:30', '1', NULL, '2076896', '-23.448524', '-46.5902191', 'Rua Ribeiro de Vasconcelos, 28 - Jardim Joamar, São Paulo - SP, Brasil', NULL, '0', '1552', 'LEPTOSPIROSE', 'Exame Nao Realizado'),
('07/01/2021', '7251658', 'MARIA EDUARDA ANDRADE DE SOUZA SALU', '948875384', '11', '38', '3814', '02263-030', 'RUA', 'TOMAS CYRO POZZI', '261', 'CASA 03', 'JARDIM ALIANCA', 'UBS JACANA', '43-T04', NULL, NULL, NULL, '25/12/2020', '202052', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '04/01/2021', 'CONJUNTO HOSPITALAR DO MANDAQUI SAO PAULO', '202101', NULL, NULL, 'D788796', '2021-01-07 10:13:53', NULL, '17/11/2009', NULL, NULL, '0', NULL, '2077574', '-23.462532', '-46.57458979999999', 'Rua Thomaz Cyro Pozzi, 261 - Vila Nova Carolina, São Paulo - SP, Brasil', NULL, '0', '1734', 'LEPTOSPIROSE', 'Exame Nao Realizado'),
('29/01/2021', '7251696', 'JOSE FABIANO DO NASCIMENTO', '', '11', '83', '8301', '02326-010', 'RUA', 'KOTINDA', '1696', 'CASA', 'TREMEMBE', 'UBS JARDIM DAS PEDRAS', 'A79-P25', NULL, NULL, NULL, '01/01/2021', '202053', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '14/01/2021', 'CONJUNTO HOSPITALAR DO MANDAQUI SAO PAULO', '202102', NULL, NULL, 'D788796', '2021-01-29 11:49:09', NULL, '03/12/1991', NULL, NULL, '0', NULL, '2077574', '-23.430597', '-46.58766929999999', 'Rua Kotinda - Jardim Felicidade (Zona Norte), São Paulo - SP, Brasil', NULL, '0', '1061', 'LEPTOSPIROSE', 'Exame Nao Realizado'),
('30/04/2021', '7300822', 'ROGER HENRIQUE MENDES PENTEADO', '992830238', '11', '83', '8304', '02323-060', 'RUA', 'OTAVIO PRANDINO', '51', 'CASA 4', 'JD. MARTINS SILVA', 'UBS J FONTALIS', '15-B02', NULL, NULL, NULL, '23/03/2021', '202112', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '08/04/2021', 'CONJUNTO HOSPITALAR DO MANDAQUI SAO PAULO', '202114', NULL, NULL, 'D788796', '2021-04-30 09:25:20', NULL, '26/12/1996', NULL, NULL, '0', NULL, '2077574', '-23.438081', '-46.5846447', 'Rua Otávio Prandino, 51 - Jardim Martins Silva, São Paulo - SP, 02365-015, Brazil', NULL, '0', '1401', 'LEPTOSPIROSE', 'Exame Nao Realizado'),
('05/11/2021', '7373741', 'YASMYM SOUZA MARINHO', '995919716', '11', '83', '8301', '02364-000', 'RUA', 'CARLOS DE SOUSA ANHUMAS, BR.', '400', '', 'TREMEMBE', 'UBS J FONTALIS', 'A80-D29', NULL, '05/11/2021', NULL, '24/09/2021', '202138', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '05/10/2021', 'CONJUNTO HOSPITALAR DO MANDAQUI SAO PAULO', '202140', NULL, NULL, 'D790072', '2021-11-05 08:10:06', NULL, '06/01/2008', 'D790072', '2021-11-05 08:11:38', '1', NULL, '2077574', '-23.435682', '-46.58260780000001', 'Rua Barão Carlos de Sousa Anhumas, 400 - Jardim Recanto Verde, São Paulo - SP, 02364-000, Brazil', NULL, '0', '493', 'LEPTOSPIROSE', 'Exame Nao Realizado'),
('28/10/2021', '7382575', 'MARIA APARECIDA SILVA BRAZ', '967432735', '11', '83', '8311', '02314-000', 'AVENIDA', 'MARIO PERNAMBUCO', '626', 'BL 02 APTO 32', 'VILA NOVA MAZZEI', 'UBS J JOAMAR', '42-D5', NULL, '28/10/2021', NULL, '23/09/2021', '202138', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '20/10/2021', '', '202142', NULL, NULL, 'D790072', '2021-10-28 08:19:24', NULL, '20/03/1962', 'D790072', '2021-10-28 08:19:42', '1', NULL, '9150781', '-23.461533', '-46.6000558', 'Avenida Mário Pernambuco, 626 - Vila Nova Mazzei, São Paulo - SP, 02314-000, Brazil', NULL, '0', '1268', 'LEPTOSPIROSE', 'Exame Nao Realizado');
