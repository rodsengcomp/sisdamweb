
-- --------------------------------------------------------

--
-- Estrutura da tabela `materiais`
--

CREATE TABLE `materiais` (
  `id_material` int(3) DEFAULT NULL,
  `nome_material` varchar(100) DEFAULT NULL,
  `usuariocad` varchar(20) DEFAULT 'sistema',
  `criado` datetime NOT NULL DEFAULT '2018-08-02 13:43:48',
  `usuarioalt` varchar(20) DEFAULT NULL,
  `alterado` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `materiais`
--

INSERT INTO `materiais` (`id_material`, `nome_material`, `usuariocad`, `criado`, `usuarioalt`, `alterado`) VALUES
(1, 'ABATE (LT)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(2, 'ALCOOL(UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(3, 'ALMOTOLIA (PISSETA)(UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(4, 'ARAME KG', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(5, 'BARATICIDA COLTGEL (UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(6, 'BARATICIDA GEL (ARRAZE)(UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(7, 'BARATICIDA GEL (SULFURAMIDA)(UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(8, 'BARATICIDA PIRETROIDE(UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(9, 'BOLETINS C/C (UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(10, 'BOLETINS P.E.(UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(11, 'BOTAS BORRACHA (UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(12, 'BOTAS CORO (UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(13, 'CAIXA DE ISCA DE RODENTICIDA(UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(14, 'CALCA(UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(15, 'CAPA DE CHUVA (AMARELA)(UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(16, 'CIPERMETRINA (25G) (UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(17, 'FILTRO NEBULIZACAO', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(18, 'FRASCO (LAVA OLHOS) (UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(19, 'FRASCO DDE NOVATRURON(UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(20, 'FRASCO DE DIFLUBENZURON (UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(21, 'GUIA DE RUA', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(22, 'ISCA GRANULADA (BARATA /FORMIGA) (UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(23, 'LANTEC (UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(24, 'LUVA AMARELA G (PAR)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(25, 'LUVA AMARELA M (PAR)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(26, 'LUVA AMARELA P (PAR)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(27, 'LUVA NITRILICA G (PAR)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(28, 'LUVA NITRILICA M (PAR)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(29, 'LUVA NITRILICA P (PAR)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(30, 'LUVA PROCEDIMENTO (UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(31, 'LUVA RASPA (PAR)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(32, 'MASCARA FILTRO (UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(33, 'MASCARA SEMI FACIAL (UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(34, 'MEDIDOR DE DIFLUBENZURON (UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(35, 'OCULOS DE SEGURANCA (UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(36, 'PE DE CABRA (UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(54, 'PENEIRA', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(37, 'PIPETA (UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(38, 'PRANCHETA (UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(39, 'PROTETOR AUDITIVO DESCARTAVEL (UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(40, 'PROTETOR AUDITIVO GRANDE (UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(41, 'PROTETOR SOLAR (UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(52, 'ROUPA APICULTOR (COMPLETA) (UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(42, 'ROUPA NEB ALGODAO G(UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(43, 'ROUPA NEB ALGODAO GG (UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(44, 'ROUPA NEB ALGODAO M (UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(45, 'ROUPA NEB ALGODAO P (UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(46, 'SABONETE(GLICERINADO PEQUENO) (UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(52, 'SACO LIXO LARANJA', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(55, 'TELA DE CAIXA 1000 LTS', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(52, 'TELA DE CAIXA 250 LTS', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(54, 'TELA DE CAIXA 500 LTS', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(47, 'ZE GOTINHA G (UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(48, 'ZE GOTINHA GG (UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(49, 'ZE GOTINHA M (UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(50, 'ZE GOTINHA P (UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(51, 'ZE GOTINHA XG (UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL),
(53, 'ZE GOTINHA XXG (UN)', 'sistema', '2018-08-02 13:43:48', NULL, NULL);
