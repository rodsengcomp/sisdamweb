
-- --------------------------------------------------------

--
-- Estrutura da tabela `tblfebrea_2020`
--

CREATE TABLE `tblfebrea_2020` (
  `DataEntrada` varchar(10) DEFAULT NULL,
  `nDoc` int(7) DEFAULT NULL,
  `NomeSolicitante` varchar(100) NOT NULL,
  `Impressao` int(2) DEFAULT 0,
  `Descarte` int(2) DEFAULT 0,
  `DataAlteracao` datetime DEFAULT current_timestamp(),
  `TelefoneFixo` varchar(9) DEFAULT NULL,
  `Ddd` varchar(4) NOT NULL DEFAULT '(11)',
  `Da` int(2) DEFAULT NULL,
  `Setor1` int(4) DEFAULT NULL,
  `Cep1` varchar(9) DEFAULT NULL,
  `Logradouro` varchar(25) DEFAULT NULL,
  `Endereco1` varchar(100) DEFAULT NULL,
  `N` varchar(10) DEFAULT NULL,
  `Complemento` varchar(40) DEFAULT NULL,
  `Bairro1` varchar(50) DEFAULT NULL,
  `UBS1` varchar(30) DEFAULT NULL,
  `PgGuia1` varchar(7) DEFAULT NULL,
  `Observacoes` varchar(200) DEFAULT NULL,
  `DataBloqueio` varchar(10) DEFAULT NULL,
  `DataNeb` varchar(10) DEFAULT NULL,
  `Data1Sintomas` varchar(10) DEFAULT NULL,
  `Se1Sintomas` int(6) DEFAULT NULL,
  `ResultadoIAL` varchar(30) DEFAULT NULL,
  `DataColeta` varchar(10) DEFAULT NULL,
  `DataResultado` varchar(10) DEFAULT NULL,
  `AutoctoneImportado` varchar(1) DEFAULT NULL,
  `LPICidade` varchar(10) DEFAULT NULL,
  `LpiEstado` varchar(10) DEFAULT NULL,
  `Fechamento` varchar(10) DEFAULT NULL,
  `UnidadeNotificadora` varchar(58) DEFAULT NULL,
  `usuarioExame` varchar(13) DEFAULT NULL,
  `DataAlteracaoExame` varchar(19) DEFAULT NULL,
  `usuarioAlteracao` varchar(13) DEFAULT NULL,
  `DataNotificacao` varchar(10) DEFAULT NULL,
  `SeDataNotificacao` int(6) DEFAULT NULL,
  `DataNascimento` varchar(10) DEFAULT NULL,
  `DataObito` varchar(10) DEFAULT NULL,
  `CnesUnidadeNotificadora` int(7) DEFAULT NULL,
  `usuarioLer` varchar(13) DEFAULT NULL,
  `DataLer` varchar(19) DEFAULT NULL,
  `Latitude` varchar(30) DEFAULT NULL,
  `Longitude` varchar(30) DEFAULT NULL,
  `RuaGoogle` varchar(67) DEFAULT NULL,
  `idRua` varchar(4) DEFAULT NULL,
  `agravo` varchar(20) NOT NULL DEFAULT 'FEBRE AMARELA',
  `type` varchar(20) NOT NULL DEFAULT 'febre-amarela',
  `ResultadoTr` varchar(19) NOT NULL DEFAULT 'Exame Nao Realizado'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `tblfebrea_2020`
--

INSERT INTO `tblfebrea_2020` (`DataEntrada`, `nDoc`, `NomeSolicitante`, `Impressao`, `Descarte`, `DataAlteracao`, `TelefoneFixo`, `Ddd`, `Da`, `Setor1`, `Cep1`, `Logradouro`, `Endereco1`, `N`, `Complemento`, `Bairro1`, `UBS1`, `PgGuia1`, `Observacoes`, `DataBloqueio`, `DataNeb`, `Data1Sintomas`, `Se1Sintomas`, `ResultadoIAL`, `DataColeta`, `DataResultado`, `AutoctoneImportado`, `LPICidade`, `LpiEstado`, `Fechamento`, `UnidadeNotificadora`, `usuarioExame`, `DataAlteracaoExame`, `usuarioAlteracao`, `DataNotificacao`, `SeDataNotificacao`, `DataNascimento`, `DataObito`, `CnesUnidadeNotificadora`, `usuarioLer`, `DataLer`, `Latitude`, `Longitude`, `RuaGoogle`, `idRua`, `agravo`, `type`, `ResultadoTr`) VALUES
('15/12/2020', 7215726, 'JACKSON SANTANA DE JESUS', 1, 0, '2020-12-15 07:48:01', '980592913', '11', 38, 3805, '02230-040', 'RUA', 'BAIA DE SANTA CLARA', '545', 'APTO. 24 - BL. 17', 'EDU CHAVES', 'UBS PQ EDU CHAVES', '72-M03', NULL, '15/12/2020', '', '23/11/2020', 202048, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'HOSP MAT NSRA DO ROSARIO', NULL, NULL, 'D790072', '04/12/2020', 202049, '08/12/1994', NULL, 2084368, 'D790072', '2020-12-15 07:48:22', '-23.4826646', '-46.56161119999999', 'Rua Baía de Santa Clara, 545 - Parque Edu Chaves, São Paulo - SP, 0', '310', 'FEBRE AMARELA', 'febre-amarela', 'Exame Nao Realizado'),
('23/09/2020', 7167349, 'RODRIGO SOUZA JORGE', 1, 0, '2020-09-23 07:29:42', '840152312', '11', 83, 8308, '02325-000', 'RUA', 'FILHOS DA TERRA, DOS *', '387', '', 'JD. FILHOS DA TERRA', 'UBS J APUANA', '', NULL, '23/09/2020', '', '09/09/2020', 202037, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'HOSPITAL SALVALUS', NULL, NULL, 'D790072', '16/09/2020', 202038, '01/03/1982', NULL, 9554157, 'D790072', '2020-09-23 07:30:03', '-23.4540792', '-46.5848719', 'Rua dos Filhos da Terra, 387 - Jardim Joamar, São Paulo - SP, Brasi', '703', 'FEBRE AMARELA', 'febre-amarela', 'Exame Nao Realizado'),
('22/06/2020', 6848745, 'WAGNER APARECIDO BISPO', 1, 0, '2020-06-22 07:34:40', '999901979', '11', 83, 8302, '02364-770', 'ALAMEDA', 'TUCANOS, DOS', '22', '', 'TREMEMBE', 'UBS J FONTALIS', 'A80-J27', NULL, '23/06/2020', '', '28/05/2020', 202022, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'UBS V ALBERTINA DR OSVALDO MARCAL', NULL, NULL, 'D790072', '16/06/2020', 202025, '09/08/1984', NULL, 2027275, 'D784549', '2020-06-23 07:45:32', '-23.4344496', '-46.58056130000001', 'Alameda dos Tucanos, 22 - Jardim Estrela D\'alva, São Paulo - SP, 02', '1750', 'FEBRE AMARELA', 'febre-amarela', 'Exame Nao Realizado');
