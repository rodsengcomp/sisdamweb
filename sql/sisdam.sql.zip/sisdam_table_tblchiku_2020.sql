
-- --------------------------------------------------------

--
-- Estrutura da tabela `tblchiku_2020`
--

CREATE TABLE `tblchiku_2020` (
  `DataEntrada` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `nDoc` int(7) DEFAULT NULL,
  `NomeSolicitante` varchar(100) CHARACTER SET utf8 NOT NULL,
  `ResultadoIAL` varchar(30) CHARACTER SET utf8 DEFAULT 'Exame Nao Realizado',
  `Impressao` int(2) DEFAULT 0,
  `Descarte` int(2) DEFAULT 0,
  `DataAlteracao` datetime DEFAULT current_timestamp(),
  `TelefoneFixo` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `Ddd` varchar(4) CHARACTER SET utf8 NOT NULL DEFAULT '(11)',
  `Da` int(2) DEFAULT NULL,
  `Setor1` int(4) DEFAULT NULL,
  `Cep1` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `Logradouro` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `Endereco1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `N` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `Complemento` varchar(40) CHARACTER SET utf8 DEFAULT NULL,
  `Bairro1` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `UBS1` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `PgGuia1` varchar(7) CHARACTER SET utf8 DEFAULT NULL,
  `Observacoes` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `DataBloqueio` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `DataNeb` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `Data1Sintomas` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `Se1Sintomas` int(6) DEFAULT NULL,
  `DataColeta` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `DataResultado` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `AutoctoneImportado` varchar(1) CHARACTER SET utf8 DEFAULT NULL,
  `LPICidade` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `LpiEstado` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `Fechamento` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `UnidadeNotificadora` varchar(58) CHARACTER SET utf8 DEFAULT NULL,
  `usuarioExame` varchar(13) CHARACTER SET utf8 DEFAULT NULL,
  `DataAlteracaoExame` varchar(19) CHARACTER SET utf8 DEFAULT NULL,
  `usuarioAlteracao` varchar(13) CHARACTER SET utf8 DEFAULT NULL,
  `DataNotificacao` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `SeDataNotificacao` int(6) DEFAULT NULL,
  `DataNascimento` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `DataObito` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `CnesUnidadeNotificadora` int(7) DEFAULT NULL,
  `usuarioLer` varchar(13) CHARACTER SET utf8 DEFAULT NULL,
  `DataLer` varchar(19) CHARACTER SET utf8 DEFAULT NULL,
  `Latitude` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `Longitude` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `RuaGoogle` varchar(67) CHARACTER SET utf8 DEFAULT NULL,
  `idRua` varchar(4) CHARACTER SET utf8 DEFAULT NULL,
  `type` varchar(15) CHARACTER SET utf8 NOT NULL DEFAULT 'Chikungunya',
  `agravo` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT 'CHIKUNGUNYA',
  `ResultadoTr` varchar(19) COLLATE latin1_general_ci NOT NULL DEFAULT 'Exame Nao Realizado'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci ROW_FORMAT=COMPACT;

--
-- Extraindo dados da tabela `tblchiku_2020`
--

INSERT INTO `tblchiku_2020` (`DataEntrada`, `nDoc`, `NomeSolicitante`, `ResultadoIAL`, `Impressao`, `Descarte`, `DataAlteracao`, `TelefoneFixo`, `Ddd`, `Da`, `Setor1`, `Cep1`, `Logradouro`, `Endereco1`, `N`, `Complemento`, `Bairro1`, `UBS1`, `PgGuia1`, `Observacoes`, `DataBloqueio`, `DataNeb`, `Data1Sintomas`, `Se1Sintomas`, `DataColeta`, `DataResultado`, `AutoctoneImportado`, `LPICidade`, `LpiEstado`, `Fechamento`, `UnidadeNotificadora`, `usuarioExame`, `DataAlteracaoExame`, `usuarioAlteracao`, `DataNotificacao`, `SeDataNotificacao`, `DataNascimento`, `DataObito`, `CnesUnidadeNotificadora`, `usuarioLer`, `DataLer`, `Latitude`, `Longitude`, `RuaGoogle`, `idRua`, `type`, `agravo`, `ResultadoTr`) VALUES
('04/12/2020', 7201725, 'FERNANDO ABILIO LOURENCO', 'Exame Nao Realizado', 0, 0, '2020-12-04 07:41:15', '35695325', '11', 83, 8313, '02375-000', 'RUA', 'SAO CLETO', '237', '', 'VILA IRMAOS ARNONI', 'UBS DONA MARIQUINHA SCIASCIA', '12-N17', NULL, '', '', '14/11/2020', 202046, NULL, NULL, NULL, NULL, NULL, NULL, 'UBS WAMBERTO DIAS DA COSTA', NULL, NULL, 'D790072', '21/11/2020', 202047, '25/02/1959', NULL, 4049985, NULL, NULL, '-23.4521000', '-46.6252799', 'Rua SÃ£o Cleto, Vila IrmÃ£os Arnoni, Sao Paulo - SP, 02375-000, Bra', '1617', 'Chikungunya', 'CHIKUNGUNYA', 'Exame Nao Realizado'),
('15/06/2020', 6893012, 'MARIO DIAS CACERES', 'Exame Nao Realizado', 0, 0, '2020-06-15 08:56:05', '981857844', '11', 38, 8320, '02228-060', 'RUA', 'PASQUALE MONTANI', '15', '', 'PQ. EDU CHAVES', 'UBS PQ EDU CHAVES', '043-U22', NULL, NULL, NULL, '30/03/2020', 202014, NULL, NULL, NULL, NULL, NULL, NULL, 'UBS PQ EDU CHAVES', NULL, NULL, 'D791749', '27/04/2020', 202018, '06/01/1987', NULL, 2788306, NULL, NULL, '-23.4744112', '-46.5711543', 'Rua Pasquale Montani, 15 - Parque Edu Chaves, São Paulo - SP, 02228', '1433', 'Chikungunya', 'CHIKUNGUNYA', 'Exame Nao Realizado'),
('02/09/2020', 7209391, 'NEUMA APARECIDA DE OLIVEIRA', 'Exame Nao Realizado', 0, 0, '2020-09-02 09:28:24', '0', '11', 83, 8317, '02322-140', 'RUA', 'DORA DALMER', '386', '', 'VILA VIRGINIA', 'UBS J JOAMAR', '14-O11', NULL, NULL, NULL, '01/08/2020', 202031, NULL, NULL, NULL, NULL, NULL, NULL, 'HOSPITAL IGESP', NULL, NULL, 'D790072', '12/08/2020', 202033, '23/08/1983', NULL, 2084333, NULL, NULL, '-23.44431329999999', '-46.5923431', 'Rua Dora Dalmer, 386 - Vila Dona Augusta, São Paulo - SP, 02322-140', '605', 'Chikungunya', 'CHIKUNGUNYA', 'Exame Nao Realizado');
