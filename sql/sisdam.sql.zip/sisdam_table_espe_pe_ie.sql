
-- --------------------------------------------------------

--
-- Estrutura da tabela `espe_pe_ie`
--

CREATE TABLE `espe_pe_ie` (
  `id_esp_pe_ie` int(11) NOT NULL,
  `especificacao_pe_ie` varchar(24) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `espe_pe_ie`
--

INSERT INTO `espe_pe_ie` (`id_esp_pe_ie`, `especificacao_pe_ie`) VALUES
(1, 'AREA DESOCUPADA'),
(2, 'ATERRO'),
(3, 'AUTO PECAS'),
(4, 'BORRACHARIA'),
(5, 'CEMITERIO'),
(6, 'CLUBE'),
(7, 'COMERCIO TAMBOR'),
(8, 'DESMANCHE'),
(9, 'ESCOLA'),
(10, 'FABRICA DE MOVEIS'),
(11, 'FABRICA DE TUBOS'),
(12, 'FERRO VELHO'),
(13, 'FLORICULTURA'),
(14, 'GARRAFAS'),
(15, 'MATERIAL DE CONSTRUCAO'),
(16, 'MECANICA CAMINHAO'),
(17, 'OFICINA MECANICA'),
(18, 'PEÃAS DE TRATORES'),
(19, 'POSTO'),
(20, 'RECICLAGEM'),
(21, 'SEMINARIO'),
(22, 'SERRALHERIA'),
(23, 'SUCATA'),
(24, 'TAMBORES'),
(25, 'TECELAGEM'),
(26, 'TRANSPORTADORA'),
(27, 'UNIDADE DE SAUDE');
