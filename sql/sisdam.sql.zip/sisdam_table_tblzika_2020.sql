
-- --------------------------------------------------------

--
-- Estrutura da tabela `tblzika_2020`
--

CREATE TABLE `tblzika_2020` (
  `DataEntrada` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `nDoc` int(7) DEFAULT NULL,
  `NomeSolicitante` varchar(100) CHARACTER SET utf8 NOT NULL,
  `ResultadoIAL` varchar(30) CHARACTER SET utf8 DEFAULT 'Exame Nao Realizado',
  `Impressao` int(2) DEFAULT 0,
  `Descarte` int(2) DEFAULT 0,
  `DataAlteracao` datetime DEFAULT current_timestamp(),
  `TelefoneFixo` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `Ddd` varchar(4) CHARACTER SET utf8 NOT NULL DEFAULT '(11)',
  `Da` int(2) DEFAULT NULL,
  `Setor1` int(4) DEFAULT NULL,
  `Cep1` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `Logradouro` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `Endereco1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `N` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `Complemento` varchar(40) CHARACTER SET utf8 DEFAULT NULL,
  `Bairro1` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `UBS1` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `PgGuia1` varchar(7) CHARACTER SET utf8 DEFAULT NULL,
  `Observacoes` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `DataBloqueio` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `DataNeb` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `Data1Sintomas` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `Se1Sintomas` int(6) DEFAULT NULL,
  `DataColeta` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `DataResultado` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `AutoctoneImportado` varchar(1) CHARACTER SET utf8 DEFAULT NULL,
  `LPICidade` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `LpiEstado` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `Fechamento` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `UnidadeNotificadora` varchar(58) CHARACTER SET utf8 DEFAULT NULL,
  `usuarioExame` varchar(13) CHARACTER SET utf8 DEFAULT NULL,
  `DataAlteracaoExame` varchar(19) CHARACTER SET utf8 DEFAULT NULL,
  `usuarioAlteracao` varchar(13) CHARACTER SET utf8 DEFAULT NULL,
  `DataNotificacao` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `SeDataNotificacao` int(6) DEFAULT NULL,
  `DataNascimento` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `DataObito` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `CnesUnidadeNotificadora` int(7) DEFAULT NULL,
  `usuarioLer` varchar(13) CHARACTER SET utf8 DEFAULT NULL,
  `DataLer` varchar(19) CHARACTER SET utf8 DEFAULT NULL,
  `Latitude` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `Longitude` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `RuaGoogle` varchar(67) CHARACTER SET utf8 DEFAULT NULL,
  `idRua` varchar(4) CHARACTER SET utf8 DEFAULT NULL,
  `type` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT 'Febre Pelo Virus Zika',
  `agravo` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT 'FEBRE PELO VIRUS ZIKA',
  `ResultadoTr` varchar(20) COLLATE latin1_general_ci NOT NULL DEFAULT 'Exame Não Realizado'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci ROW_FORMAT=COMPACT;

--
-- Extraindo dados da tabela `tblzika_2020`
--

INSERT INTO `tblzika_2020` (`DataEntrada`, `nDoc`, `NomeSolicitante`, `ResultadoIAL`, `Impressao`, `Descarte`, `DataAlteracao`, `TelefoneFixo`, `Ddd`, `Da`, `Setor1`, `Cep1`, `Logradouro`, `Endereco1`, `N`, `Complemento`, `Bairro1`, `UBS1`, `PgGuia1`, `Observacoes`, `DataBloqueio`, `DataNeb`, `Data1Sintomas`, `Se1Sintomas`, `DataColeta`, `DataResultado`, `AutoctoneImportado`, `LPICidade`, `LpiEstado`, `Fechamento`, `UnidadeNotificadora`, `usuarioExame`, `DataAlteracaoExame`, `usuarioAlteracao`, `DataNotificacao`, `SeDataNotificacao`, `DataNascimento`, `DataObito`, `CnesUnidadeNotificadora`, `usuarioLer`, `DataLer`, `Latitude`, `Longitude`, `RuaGoogle`, `idRua`, `type`, `agravo`, `ResultadoTr`) VALUES
('06/01/2020', 6495871, 'ANA MARIA PINHEIRO', 'Exame Nao Realizado', 2, 0, '2020-01-06 07:54:59', '983324721', '11', 83, 8304, '02323-220', 'RUA', 'FAUSTO DOMINGUES *', '161', 'CASA 03', 'JD. MARTINS SILVA', 'UBS J FONTALIS', '15-L01', NULL, NULL, NULL, '19/12/2018', 201851, NULL, NULL, NULL, NULL, NULL, NULL, 'HOSP SAO LUIZ GONZAGA', NULL, NULL, 'D790072', '08/01/2019', 201902, '20/07/1984', NULL, 2076896, 'D790072', '2020-01-06 07:56:37', '-23.4382124', '-46.57819619999998', 'Rua Fausto Domingues, 161 - Jardim Martins Silva, São Paulo - SP, 0', '673', 'Febre Pelo Virus Zika', 'FEBRE PELO VIRUS ZIKA', 'Exame Nao Realizado'),
('06/01/2020', 3879196, 'DIONICIA PAIRO PAINA', 'Exame Nao Realizado', 2, 0, '2020-01-06 07:55:31', '995956946', '11', 83, 8304, '02361-160', 'RUA', 'FRANCISCO BAGATTI *', '76', '', 'TREMEMBE', 'UBS J FONTALIS', '15-F02', NULL, NULL, NULL, '24/04/2019', 201917, NULL, NULL, NULL, NULL, NULL, NULL, 'HOSP MUN VER JOSE STOROPOLLI', NULL, NULL, 'D790072', '30/04/2019', 201918, '21/12/1986', NULL, 3212130, 'D790072', '2020-01-06 07:56:30', '-23.4383489', '-46.58025429999998', 'Rua Francisco Bagatti, 76 - Associacao Sobradinho, São Paulo - SP, ', '737', 'Febre Pelo Virus Zika', 'FEBRE PELO VIRUS ZIKA', 'Exame Nao Realizado'),
('06/01/2020', 4509857, 'JOYCE HELENA SILVA', 'Exame Nao Realizado', 2, 0, '2020-01-06 07:55:17', '983101775', '11', 83, 8315, '02367-365', 'RUA', 'SERESTA , DA', '12', 'CASA B', 'FURNAS', 'UBS JARDIM DAS PEDRAS', 'A79S08', NULL, NULL, NULL, '09/01/2019', 201902, NULL, NULL, NULL, NULL, NULL, NULL, 'UBS JARDIM DAS PEDRAS', NULL, NULL, 'D790072', '17/01/2019', 201903, '05/06/1986', NULL, 3323331, 'D790072', '2020-01-06 07:56:33', '-23.4248651', '-46.588805200000024', 'Rua da Seresta, 12 - Furnas, São Paulo - SP, Brasil', '1661', 'Febre Pelo Virus Zika', 'FEBRE PELO VIRUS ZIKA', 'Exame Nao Realizado');
