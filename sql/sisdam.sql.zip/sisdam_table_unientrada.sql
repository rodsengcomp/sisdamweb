
-- --------------------------------------------------------

--
-- Estrutura da tabela `unientrada`
--

CREATE TABLE `unientrada` (
  `id` int(11) NOT NULL,
  `unientrada` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `unientrada`
--

INSERT INTO `unientrada` (`id`, `unientrada`) VALUES
(1, 'V. AMBIENTAL'),
(2, 'V. EPIDEMIO'),
(3, 'REC. HUMANOS'),
(4, 'V. SANITARIA'),
(5, 'UVIS JACANA/TREMEMBE');
