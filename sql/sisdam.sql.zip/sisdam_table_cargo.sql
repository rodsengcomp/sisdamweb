
-- --------------------------------------------------------

--
-- Estrutura da tabela `cargo`
--

CREATE TABLE `cargo` (
  `id` int(2) NOT NULL,
  `cargo` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `cargo`
--

INSERT INTO `cargo` (`id`, `cargo`) VALUES
(1, 'Agente de Apoio'),
(2, 'Agente de Saúde - Endemias'),
(3, 'Analista de Assistência e Desenvolvimento Social'),
(4, 'Analista de Saúde - Odontologia'),
(5, 'Analista de Saúde - Biologia'),
(6, 'Analista de Saúde - Enfermagem'),
(7, 'Analista de Saúde - Farmacéutico'),
(8, 'Analista de Saúde - Médico'),
(9, 'Analista de Saúde - Médico Veterinário'),
(10, 'Analista de Saúde - Odontologia'),
(11, 'Analista de Saúde - Psicologia'),
(12, 'Assistente de Gestão e Politicas Públicas'),
(14, 'Oficial Administrativo'),
(15, 'Enfermeira');
