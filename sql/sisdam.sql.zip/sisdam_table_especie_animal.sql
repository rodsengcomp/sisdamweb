
-- --------------------------------------------------------

--
-- Estrutura da tabela `especie_animal`
--

CREATE TABLE `especie_animal` (
  `id_especie` int(11) NOT NULL,
  `especie` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `especie_animal`
--

INSERT INTO `especie_animal` (`id_especie`, `especie`) VALUES
(1, 'FELINA'),
(2, 'CANINA'),
(3, 'OUTROS');
