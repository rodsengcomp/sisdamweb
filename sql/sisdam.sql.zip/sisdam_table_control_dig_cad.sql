
-- --------------------------------------------------------

--
-- Estrutura da tabela `control_dig_cad`
--

CREATE TABLE `control_dig_cad` (
  `id_control` int(11) NOT NULL,
  `ano_dig` int(4) NOT NULL,
  `table_dig` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
