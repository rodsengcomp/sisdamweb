
-- --------------------------------------------------------

--
-- Estrutura da tabela `esporo_an_ent_medc`
--

CREATE TABLE `esporo_an_ent_medc` (
  `id_esp_ent` int(11) NOT NULL,
  `dt_cadastro` text NOT NULL,
  `nm_esp_medc` int(11) NOT NULL,
  `dsg_esp_medc` int(11) NOT NULL,
  `qtd_esp_medc` int(11) NOT NULL,
  `lixeira` int(11) NOT NULL DEFAULT 0,
  `criado` text NOT NULL,
  `dt_criado` timestamp NOT NULL DEFAULT current_timestamp(),
  `alterado` text NOT NULL,
  `dt_alterado` text NOT NULL,
  `excluido` text NOT NULL,
  `data_excluido` date DEFAULT NULL,
  `reativado` text NOT NULL,
  `data_reativado` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
