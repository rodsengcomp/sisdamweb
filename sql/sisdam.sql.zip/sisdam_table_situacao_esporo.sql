
-- --------------------------------------------------------

--
-- Estrutura da tabela `situacao_esporo`
--

CREATE TABLE `situacao_esporo` (
  `id_st_esp` int(11) NOT NULL,
  `sit_esp` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `situacao_esporo`
--

INSERT INTO `situacao_esporo` (`id_st_esp`, `sit_esp`) VALUES
(1, 'ALTA'),
(2, 'DESAPARECIDO'),
(3, 'DESCARTADO'),
(4, 'DOOU ANIMAL'),
(5, 'EM TRATAMENTO'),
(6, 'FUGA'),
(7, 'MUDOU-SE'),
(8, 'NÃO LOCALIZADO'),
(9, 'NEGATIVO'),
(10, 'OBITO'),
(11, 'RECIDIVA'),
(12, 'EM ABERTO');
