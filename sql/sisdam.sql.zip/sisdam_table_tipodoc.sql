
-- --------------------------------------------------------

--
-- Estrutura da tabela `tipodoc`
--

CREATE TABLE `tipodoc` (
  `id` int(11) NOT NULL,
  `tipodoc` varchar(100) DEFAULT NULL,
  `usuariocad` varchar(20) DEFAULT 'sistema',
  `criado` datetime DEFAULT NULL,
  `usuarioalt` varchar(20) DEFAULT NULL,
  `alterado` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- Extraindo dados da tabela `tipodoc`
--

INSERT INTO `tipodoc` (`id`, `tipodoc`, `usuariocad`, `criado`, `usuarioalt`, `alterado`) VALUES
(1, 'MEMORANDO', 'sistema', NULL, NULL, NULL),
(2, 'OFICIO', 'sistema', NULL, NULL, NULL);
