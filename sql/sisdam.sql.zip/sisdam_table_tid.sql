
-- --------------------------------------------------------

--
-- Estrutura da tabela `tid`
--

CREATE TABLE `tid` (
  `id` int(11) NOT NULL,
  `ndoc` int(11) NOT NULL,
  `tipo` varchar(20) DEFAULT NULL,
  `identificacao` varchar(200) DEFAULT NULL,
  `dataentrada` varchar(10) DEFAULT NULL,
  `assunto` varchar(50) DEFAULT NULL,
  `tecnico_rec` varchar(50) DEFAULT NULL,
  `orgorigem` varchar(100) DEFAULT NULL,
  `uniorigem` varchar(150) DEFAULT NULL,
  `descricao` varchar(150) DEFAULT NULL,
  `unidestino` varchar(100) DEFAULT NULL,
  `datatramitacao` varchar(10) DEFAULT NULL,
  `usuariocad` varchar(30) DEFAULT NULL,
  `criado` datetime DEFAULT NULL,
  `unientrada` varchar(100) DEFAULT NULL,
  `usuariosaida` varchar(50) DEFAULT NULL,
  `datasaida` varchar(10) DEFAULT NULL,
  `usuarioalt` varchar(30) DEFAULT NULL,
  `alterado` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `tid`
--

INSERT INTO `tid` (`id`, `ndoc`, `tipo`, `identificacao`, `dataentrada`, `assunto`, `tecnico_rec`, `orgorigem`, `uniorigem`, `descricao`, `unidestino`, `datatramitacao`, `usuariocad`, `criado`, `unientrada`, `usuariosaida`, `datasaida`, `usuarioalt`, `alterado`) VALUES
(1, 2147483647, 'MEMORANDO ', 'MEMORANDO 146/19 ', '17/07/2019', 'VOLUME DE PROCESSO N°03', 'VIGILÂNCIA SANITÁRIA', 'CASA DE REPOUSO EPP', 'CASA DE REPOUSO EPP', 'ENTREGA ANTONIO DOS SANTOS FERRINI ', '182831 SUVIS JACANA/TREMEMBE/VIGILANCIA SANITARIA', '17/07/2019', 'D708158', '2019-09-09 16:51:23', 'V. SANITARIA', NULL, NULL, 'D708158', '2019-09-09 16:58:33');
