
-- --------------------------------------------------------

--
-- Estrutura da tabela `estabelecimentos`
--

CREATE TABLE `estabelecimentos` (
  `id_est` int(11) NOT NULL,
  `cpf_cnpj_est` varchar(20) NOT NULL,
  `id_rua_est` varchar(30) DEFAULT NULL,
  `rua_google_est` varchar(120) DEFAULT NULL,
  `lat_est` varchar(30) DEFAULT NULL,
  `long_est` varchar(30) DEFAULT NULL,
  `usuariocad` varchar(7) DEFAULT NULL,
  `criado` timestamp NULL DEFAULT NULL,
  `usuarioalt` varchar(7) DEFAULT NULL,
  `alterado` timestamp NULL DEFAULT NULL,
  `n_est` varchar(6) DEFAULT NULL,
  `comp_est` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
