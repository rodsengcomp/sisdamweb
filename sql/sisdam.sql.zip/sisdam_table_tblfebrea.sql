
-- --------------------------------------------------------

--
-- Estrutura da tabela `tblfebrea`
--

CREATE TABLE `tblfebrea` (
  `DataEntrada` varchar(10) DEFAULT NULL,
  `nDoc` int(7) DEFAULT NULL,
  `NomeSolicitante` varchar(100) NOT NULL,
  `Impressao` int(2) DEFAULT 0,
  `Descarte` int(2) DEFAULT 0,
  `DataAlteracao` datetime DEFAULT current_timestamp(),
  `TelefoneFixo` varchar(9) DEFAULT NULL,
  `Ddd` varchar(4) NOT NULL DEFAULT '(11)',
  `Da` int(2) DEFAULT NULL,
  `Setor1` int(4) DEFAULT NULL,
  `Cep1` varchar(9) DEFAULT NULL,
  `Logradouro` varchar(25) DEFAULT NULL,
  `Endereco1` varchar(100) DEFAULT NULL,
  `N` varchar(10) DEFAULT NULL,
  `Complemento` varchar(40) DEFAULT NULL,
  `Bairro1` varchar(50) DEFAULT NULL,
  `UBS1` varchar(30) DEFAULT NULL,
  `PgGuia1` varchar(7) DEFAULT NULL,
  `Observacoes` varchar(200) DEFAULT NULL,
  `DataBloqueio` varchar(10) DEFAULT NULL,
  `DataNeb` varchar(10) DEFAULT NULL,
  `Data1Sintomas` varchar(10) DEFAULT NULL,
  `Se1Sintomas` int(6) DEFAULT NULL,
  `ResultadoIAL` varchar(30) DEFAULT NULL,
  `DataColeta` varchar(10) DEFAULT NULL,
  `DataResultado` varchar(10) DEFAULT NULL,
  `AutoctoneImportado` varchar(1) DEFAULT NULL,
  `LPICidade` varchar(10) DEFAULT NULL,
  `LpiEstado` varchar(10) DEFAULT NULL,
  `Fechamento` varchar(10) DEFAULT NULL,
  `UnidadeNotificadora` varchar(58) DEFAULT NULL,
  `usuarioExame` varchar(13) DEFAULT NULL,
  `DataAlteracaoExame` varchar(19) DEFAULT NULL,
  `usuarioAlteracao` varchar(13) DEFAULT NULL,
  `DataNotificacao` varchar(10) DEFAULT NULL,
  `SeDataNotificacao` int(6) DEFAULT NULL,
  `DataNascimento` varchar(10) DEFAULT NULL,
  `DataObito` varchar(10) DEFAULT NULL,
  `CnesUnidadeNotificadora` int(7) DEFAULT NULL,
  `usuarioLer` varchar(13) DEFAULT NULL,
  `DataLer` varchar(19) DEFAULT NULL,
  `Latitude` varchar(30) DEFAULT NULL,
  `Longitude` varchar(30) DEFAULT NULL,
  `RuaGoogle` varchar(67) DEFAULT NULL,
  `idRua` varchar(4) DEFAULT NULL,
  `agravo` varchar(20) NOT NULL DEFAULT 'FEBRE AMARELA',
  `type` varchar(20) NOT NULL DEFAULT 'febre-amarela',
  `ResultadoTr` varchar(19) NOT NULL DEFAULT 'Exame Nao Realizado'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `tblfebrea`
--

INSERT INTO `tblfebrea` (`DataEntrada`, `nDoc`, `NomeSolicitante`, `Impressao`, `Descarte`, `DataAlteracao`, `TelefoneFixo`, `Ddd`, `Da`, `Setor1`, `Cep1`, `Logradouro`, `Endereco1`, `N`, `Complemento`, `Bairro1`, `UBS1`, `PgGuia1`, `Observacoes`, `DataBloqueio`, `DataNeb`, `Data1Sintomas`, `Se1Sintomas`, `ResultadoIAL`, `DataColeta`, `DataResultado`, `AutoctoneImportado`, `LPICidade`, `LpiEstado`, `Fechamento`, `UnidadeNotificadora`, `usuarioExame`, `DataAlteracaoExame`, `usuarioAlteracao`, `DataNotificacao`, `SeDataNotificacao`, `DataNascimento`, `DataObito`, `CnesUnidadeNotificadora`, `usuarioLer`, `DataLer`, `Latitude`, `Longitude`, `RuaGoogle`, `idRua`, `agravo`, `type`, `ResultadoTr`) VALUES
('11/03/2022', 7288737, 'LUAN ROBERTO DORTA', 0, 0, '2022-03-11 11:33:42', '963690696', '11', 38, 3814, '02237-045', 'RUA', 'FLORES DO NILO', '01', '', 'JARDIM MODELO', 'UBS PQ EDU CHAVES', '043X11', NULL, NULL, NULL, '28/02/2022', 202209, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'HOSP SAO LUIZ GONZAGA', NULL, NULL, 'D788796', '08/03/2022', 202210, '10/06/1998', NULL, 2076896, NULL, NULL, '-23.4630443', '-46.57076929999999', 'Rua Flores do Nilo, 1 - Jardim Modelo, São Paulo - SP, Brasil', '716', 'FEBRE AMARELA', 'febre-amarela', 'Exame Nao Realizado');
