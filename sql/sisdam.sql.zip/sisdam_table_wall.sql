
-- --------------------------------------------------------

--
-- Estrutura da tabela `wall`
--

CREATE TABLE `wall` (
  `wallace` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
