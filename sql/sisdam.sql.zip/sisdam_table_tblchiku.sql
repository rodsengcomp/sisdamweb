
-- --------------------------------------------------------

--
-- Estrutura da tabela `tblchiku`
--

CREATE TABLE `tblchiku` (
  `DataEntrada` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `nDoc` int(7) DEFAULT NULL,
  `NomeSolicitante` varchar(100) CHARACTER SET utf8 NOT NULL,
  `ResultadoIAL` varchar(30) CHARACTER SET utf8 DEFAULT 'Exame Nao Realizado',
  `Impressao` int(2) DEFAULT 0,
  `Descarte` int(2) DEFAULT 0,
  `DataAlteracao` datetime DEFAULT current_timestamp(),
  `TelefoneFixo` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `Ddd` varchar(4) CHARACTER SET utf8 NOT NULL DEFAULT '(11)',
  `Da` int(2) DEFAULT NULL,
  `Setor1` int(4) DEFAULT NULL,
  `Cep1` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `Logradouro` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `Endereco1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `N` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `Complemento` varchar(40) CHARACTER SET utf8 DEFAULT NULL,
  `Bairro1` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `UBS1` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `PgGuia1` varchar(7) CHARACTER SET utf8 DEFAULT NULL,
  `Observacoes` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `DataBloqueio` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `DataNeb` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `Data1Sintomas` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `Se1Sintomas` int(6) DEFAULT NULL,
  `DataColeta` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `DataResultado` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `AutoctoneImportado` varchar(1) CHARACTER SET utf8 DEFAULT NULL,
  `LPICidade` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `LpiEstado` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `Fechamento` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `UnidadeNotificadora` varchar(58) CHARACTER SET utf8 DEFAULT NULL,
  `usuarioExame` varchar(13) CHARACTER SET utf8 DEFAULT NULL,
  `DataAlteracaoExame` varchar(19) CHARACTER SET utf8 DEFAULT NULL,
  `usuarioAlteracao` varchar(13) CHARACTER SET utf8 DEFAULT NULL,
  `DataNotificacao` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `SeDataNotificacao` int(6) DEFAULT NULL,
  `DataNascimento` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `DataObito` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `CnesUnidadeNotificadora` int(7) DEFAULT NULL,
  `usuarioLer` varchar(13) CHARACTER SET utf8 DEFAULT NULL,
  `DataLer` varchar(19) CHARACTER SET utf8 DEFAULT NULL,
  `Latitude` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `Longitude` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `RuaGoogle` varchar(67) CHARACTER SET utf8 DEFAULT NULL,
  `idRua` varchar(4) CHARACTER SET utf8 DEFAULT NULL,
  `type` varchar(15) CHARACTER SET utf8 NOT NULL DEFAULT 'Chikungunya',
  `agravo` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT 'CHIKUNGUNYA',
  `ResultadoTr` varchar(19) COLLATE latin1_general_ci NOT NULL DEFAULT 'Exame Nao Realizado'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci ROW_FORMAT=COMPACT;

--
-- Extraindo dados da tabela `tblchiku`
--

INSERT INTO `tblchiku` (`DataEntrada`, `nDoc`, `NomeSolicitante`, `ResultadoIAL`, `Impressao`, `Descarte`, `DataAlteracao`, `TelefoneFixo`, `Ddd`, `Da`, `Setor1`, `Cep1`, `Logradouro`, `Endereco1`, `N`, `Complemento`, `Bairro1`, `UBS1`, `PgGuia1`, `Observacoes`, `DataBloqueio`, `DataNeb`, `Data1Sintomas`, `Se1Sintomas`, `DataColeta`, `DataResultado`, `AutoctoneImportado`, `LPICidade`, `LpiEstado`, `Fechamento`, `UnidadeNotificadora`, `usuarioExame`, `DataAlteracaoExame`, `usuarioAlteracao`, `DataNotificacao`, `SeDataNotificacao`, `DataNascimento`, `DataObito`, `CnesUnidadeNotificadora`, `usuarioLer`, `DataLer`, `Latitude`, `Longitude`, `RuaGoogle`, `idRua`, `type`, `agravo`, `ResultadoTr`) VALUES
('19/05/2022', 8685425, 'BIANCA CRISTINA DA SILVA', 'Exame Nao Realizado', 0, 0, '2022-05-19 08:01:27', '969967749', '11', 83, 8309, '02318-270', 'RUA', 'PEDRO FURQUIM', '09', 'CASA', 'VILA PAULISTANA', 'UBS J JOAMAR', '14-R21', NULL, NULL, NULL, '10/05/2022', 202219, NULL, NULL, NULL, NULL, NULL, NULL, 'AMA UBS INTEGRADA J JOAMAR', NULL, NULL, 'D788796', '18/05/2022', 202220, '10/05/1996', NULL, 2787520, NULL, NULL, '-23.449945', '-46.590433', 'Rua Pedro Furquim, 9 - Vila Paulistana, São Paulo - SP, Brasil', '1462', 'Chikungunya', 'CHIKUNGUNYA', 'Reagente'),
('15/06/2022', 8686442, 'CLAUDINEIA FREITAS CARVALHO', 'Exame Nao Realizado', 0, 0, '2022-06-15 09:23:23', '967624640', '11', 38, 3803, '02282-040', 'RUA', 'SANTA GERTRUDES *', '14', '', 'JARDIM SAO LUIS', 'UBS V NOVA GALVAO', '16-C02', NULL, NULL, NULL, '09/05/2022', 202219, NULL, NULL, NULL, NULL, NULL, NULL, 'UPA JACANA', NULL, NULL, 'D790072', '11/05/2022', 202219, '23/01/1981', NULL, 9997091, NULL, NULL, '-23.4370953', '-46.5673795', 'Rua Santa Gertrúdes, 14 - Tres Cruzes, São Paulo - SP, Brasil', '1600', 'Chikungunya', 'CHIKUNGUNYA', 'Exame Nao Realizado'),
('17/02/2022', 7288739, 'FRANCISCA BENEDITA VIEIRA SILVA', 'Exame Nao Realizado', 0, 0, '2022-02-17 09:42:49', '94017892', '11', 83, 8306, '02323-000', 'RUA', 'USHIKICHI KAMIYA (DO INICIO AO N 520 LADO PAR E IMPAR)', '10', '', 'FURNAS', 'UBS J JOAMAR', '14-O09', NULL, NULL, NULL, '27/01/2022', 202204, NULL, NULL, NULL, NULL, NULL, NULL, 'HOSP SAO LUIZ GONZAGA', NULL, NULL, 'D790072', '07/02/2022', 202206, '05/10/1965', NULL, 2076896, NULL, NULL, '-23.4430101', '-46.5942649', 'Rua Ushikichi Kamiya, 10 - Furnas, São Paulo - SP, 02323-000, Brazi', '1762', 'Chikungunya', 'CHIKUNGUNYA', 'Exame Nao Realizado'),
('15/03/2022', 8686006, 'FRANCISCA DOS SANTOS SILVA', 'Exame Nao Realizado', 0, 0, '2022-03-15 14:14:42', '961363518', '11', 83, 8317, '02319-120', 'RUA', 'ELIAS DE ALMEIDA', '245', 'CASA', 'JARDIM JOAMAR', 'UBS J JOAMAR', '14-B17', NULL, NULL, NULL, '15/02/2022', 202207, NULL, NULL, NULL, NULL, NULL, NULL, 'AMA J JOAMAR', NULL, NULL, 'D788796', '17/02/2022', 202207, '10/08/1966', NULL, 6148395, NULL, NULL, '-23.4485922', '-46.5913969', 'Rua Elías de Almeida, 245 - Vila Paulistana, São Paulo - SP, Brasil', '626', 'Chikungunya', 'CHIKUNGUNYA', 'Exame Nao Realizado'),
('05/04/2022', 8706188, 'LARISSA BEATRIZ DE JESUS ANTONIO', 'Exame Nao Realizado', 0, 0, '2022-04-05 08:45:47', '981257293', '16', 83, 8302, '02363-105', 'RUA', 'NOSSA SENHORA APARECIDA *', '10', '', 'JARDIM FELICIDADE', 'UBS JOVA RURAL', '15-N12', NULL, NULL, NULL, '25/03/2022', 202212, NULL, NULL, NULL, NULL, NULL, NULL, 'UBS V ANGLO JOSE SERRA RIBEIRO', NULL, NULL, 'D790072', '25/03/2022', 202212, '27/09/1994', NULL, 2788683, NULL, NULL, '-23.4449077', '-46.5751593', 'Rua Nossa Senhora Aparecida, 10 - Jardim Felicidade(Zona Norte), Sã', '1366', 'Chikungunya', 'CHIKUNGUNYA', 'Exame Nao Realizado'),
('02/05/2022', 8685224, 'LAURA EDITE MIRANDA MONTEIRO', 'Exame Nao Realizado', 0, 0, '2022-05-02 09:55:29', '47080987', '11', 83, 8305, '02367-075', 'LOTEAMENTO', 'FERNAO DIAS (DO KM.76 ATE O KM.82 TUNEL)', '50', 'CASA 50', 'FERNAO DIAS KM.76 ATE O TUNEL', 'UBS JARDIM DAS PEDRAS', '00-A00', NULL, NULL, NULL, '12/04/2022', 202215, NULL, NULL, NULL, NULL, NULL, NULL, 'HOSP SAO LUIZ GONZAGA', NULL, NULL, 'D790072', '22/04/2022', 202216, '17/08/2017', NULL, 2076896, NULL, NULL, '-23.2964033', '-46.57147049999999', 'Rodovia Fernao Dias - Estrada da Barrocada - Sítio Barrocada, São P', '694', 'Chikungunya', 'CHIKUNGUNYA', 'Exame Nao Realizado'),
('18/04/2022', 8685152, 'MARIA DO SOCORRO MOREIRA DOS SANTOS', 'Exame Nao Realizado', 0, 0, '2022-04-18 09:33:45', '979773966', '11', 83, 8303, '02363-300', 'RUA', 'SARCANTO *', '31', 'CASA 01', 'VILA AYROSA', 'UBS J FLOR DE MAIO', 'A80-029', NULL, NULL, NULL, '02/04/2022', 202213, NULL, NULL, NULL, NULL, NULL, NULL, 'HOSP SAO LUIZ GONZAGA', NULL, NULL, 'D790072', '09/04/2022', 202214, '03/07/1987', NULL, 2076896, NULL, NULL, '-23.4355335', '-46.5768912', 'Rua Sarcanto, 31 - Jardim Flor de Maio, São Paulo - SP, 02363-300, ', '1648', 'Chikungunya', 'CHIKUNGUNYA', 'Exame Nao Realizado'),
('20/09/2022', 8748399, 'SANDRO MATOS SANTOS', 'Exame Nao Realizado', 0, 0, '2022-09-20 11:07:54', '954806904', '11', 83, 8306, '02323-000', 'RUA', 'USHIKICHI KAMIYA (DO INICIO AO N 520 LADO PAR E IMPAR)', '408', 'CASA 4', 'FURNAS', 'UBS J JOAMAR', '14-O09', NULL, NULL, NULL, '23/07/2022', 202229, NULL, NULL, NULL, NULL, NULL, NULL, 'AMA J JOAMAR', NULL, NULL, 'D790072', '27/07/2022', 202230, '02/05/2001', NULL, 6148395, NULL, NULL, '-23.4423195', '-46.5911513', 'Rua Ushikichi Kamiya, 408 - Furnas, São Paulo - SP, 02323-000, Braz', '1762', 'Chikungunya', 'CHIKUNGUNYA', 'Exame Nao Realizado'),
('08/07/2021', 6990529, 'VERA LUCIA DE LOURDES SILVA', 'Exame Nao Realizado', 0, 0, '2021-07-08 08:25:01', '966683166', '11', 83, 8317, '02306-004', 'AVENIDA', 'SEZEFREDO FAGUNDES, CEL. (3232 AO 5500 PAR E IMPAR)', '5169', 'APTO 14 BL E', 'TREMEMBE', 'UBS JARDIM DAS PEDRAS', '', NULL, NULL, NULL, '14/05/2021', 202119, NULL, NULL, NULL, NULL, NULL, NULL, 'HOSP DO SERV PUB MUNICIPAL HSPM', NULL, NULL, 'D790072', '14/06/2021', 202124, '13/08/1959', NULL, 2752077, NULL, NULL, '-23.4370117', '-46.5928879', 'Avenida Coronel Sezefredo Fagundes, 5169 - Tremembé, São Paulo - SP', '1676', 'Chikungunya', 'CHIKUNGUNYA', 'Exame Nao Realizado'),
('15/06/2022', 8686443, 'YASMIN RODRIGUES DE OLIVEIRA', 'Exame Nao Realizado', 0, 0, '2022-06-15 09:23:08', '983140388', '11', 83, 8318, '02352-130', 'RUA', 'PEDRO TEZIN', '34', '', 'BORTOLANDIA', 'UBS J JOAMAR', '14-H25', NULL, NULL, NULL, '09/05/2022', 202219, NULL, NULL, NULL, NULL, NULL, NULL, 'UPA JACANA', NULL, NULL, 'D790072', '11/05/2022', 202219, '11/05/2012', NULL, 9997091, NULL, NULL, '-23.4553593', '-46.5963911', 'Rua Pedro Tezin, 34 - Bortolândia, São Paulo - SP, 02352-130, Brazi', '1473', 'Chikungunya', 'CHIKUNGUNYA', 'Exame Nao Realizado');
