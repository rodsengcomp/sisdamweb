
-- --------------------------------------------------------

--
-- Estrutura da tabela `tblsarampo_2020`
--

CREATE TABLE `tblsarampo_2020` (
  `nDoc` int(7) NOT NULL,
  `NomePaciente` varchar(200) DEFAULT NULL,
  `DataEntrada` varchar(10) DEFAULT NULL,
  `N` int(10) DEFAULT NULL,
  `Complemento` varchar(100) DEFAULT NULL,
  `RuaGoogle` varchar(200) DEFAULT NULL,
  `Latitude` text DEFAULT NULL,
  `Longitude` text DEFAULT NULL,
  `idRua` int(5) DEFAULT NULL,
  `CnesUnidadeNotificadora` varchar(7) DEFAULT '0000000',
  `UnidadeNotificadora` varchar(100) DEFAULT 'NAO INFORMADO',
  `ubs` varchar(100) DEFAULT NULL,
  `agravo` varchar(20) DEFAULT 'SARAMPO',
  `type` varchar(10) DEFAULT 'Sarampo',
  `usuarioAlteracao` varchar(13) DEFAULT NULL,
  `DataAlteracao` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `tblsarampo_2020`
--

INSERT INTO `tblsarampo_2020` (`nDoc`, `NomePaciente`, `DataEntrada`, `N`, `Complemento`, `RuaGoogle`, `Latitude`, `Longitude`, `idRua`, `CnesUnidadeNotificadora`, `UnidadeNotificadora`, `ubs`, `agravo`, `type`, `usuarioAlteracao`, `DataAlteracao`) VALUES
(4347510, 'JULIANA APARECIDA MARIA DE MORAIS D', '26/02/2020', 35, 'CASA', 'Rua Emas do Serrado, 35 - Vila Ayrosa, São Paulo - SP, Brasil', '-23.4343425', '-46.56948920000001', 637, '7572182', 'CENTRO MEDICO SANTANA', 'UBS J FLOR DE MAIO', 'SARAMPO', 'Sarampo', 'D790072', '2020-02-26 08:40:25'),
(4349474, 'TAYNA ALEXANDRA COELHO DO NASCIMENT', '24/09/2020', 19, 'E', 'Rua Gabriel Ribeiro, 19 - Vila Nova Galvão, São Paulo - SP, 02281-160, Brazil', '-23.4542716', '-46.573327', 772, '9997091', 'UPA JACANA', 'UBS V NOVA GALVAO', 'SARAMPO', 'Sarampo', 'D790072', '2020-09-24 07:40:54'),
(4728918, 'MICHELE DI IORIO FILHO', '11/02/2020', 65, '', 'Rua Miguel Álvares, 65 - Horto Florestal, São Paulo - SP, Brasil', '-23.4544564', '-46.63163850000001', 1297, '2027690', 'UBS DONA MARIQUINHA SCIASCIA', 'UBS DONA MARIQUINHA SCIASCIA', 'SARAMPO', 'Sarampo', 'D790072', '2020-02-11 08:35:11'),
(5602591, 'KAROLLAYNE VITORIA PAIXAO DE OLIVEI', '24/09/2020', 180, '', 'Rua Veloso da Fonseca, 180 - Jardim Daysy, São Paulo - SP, 02358-080, Brazil', '-23.4499669', '-46.608943', 1775, '9997091', 'UPA JACANA', 'UBS V ALBERTINA DR OSVALDO MARCAL', 'SARAMPO', 'Sarampo', 'D790072', '2020-09-24 07:40:24'),
(6496330, 'MANUELLA OLIVEIRA DA SILVA', '10/07/2020', 159, '', 'Travessa Barra do Barão, 159 - Jardim Filhos da Terra, São Paulo - SP, Brasil', '-23.4541766', '-46.58554540000001', 324, '2787172', 'UBS J APUANA', 'UBS J APUANA', 'SARAMPO', 'Sarampo', 'D790072', '2020-07-10 07:48:16'),
(6848070, 'FLAVIA LOPES DE ALMEIDA', '21/02/2020', 170, 'CASA', 'Rua Avelina Pereira, 170 - Vila Nova Mazzei, São Paulo - SP, 02315-090, Brazil', '-23.4574919', '-46.6015192', 304, '2787520', 'AMA UBS INTEGRADA J JOAMAR', 'UBS J JOAMAR', 'SARAMPO', 'Sarampo', 'D790072', '2020-02-21 08:02:05'),
(6848074, 'VITORIA KEROLYN MACEDO SILVA', '21/02/2020', 152, '', 'Rua Domênico Ferrabosco, 152 - Jardim Joana D\'arc, São Paulo - SP, Brasil', '-23.4401528', '-46.58224579999999', 596, '2787520', 'AMA UBS INTEGRADA J JOAMAR', 'UBS J FONTALIS', 'SARAMPO', 'Sarampo', 'D790072', '2020-02-21 08:02:41'),
(6848077, 'LUCAS DE OLIVEIRA MARQUES', '10/03/2020', 14, '', 'Rua Bailão, 14 - Jardim Palmares (Zona Norte), São Paulo - SP, Brasil', '-23.4458104', '-46.582027', 313, '2787520', 'AMA UBS INTEGRADA J JOAMAR', 'UBS J JOAMAR', 'SARAMPO', 'Sarampo', 'D790072', '2020-03-10 08:02:01'),
(6848143, 'ALICIA GABRIELLY DA SILVA CAMARA', '02/03/2020', 4003, '', 'Rua Maria Amália Lopes Azevedo, 4003 - Tremembé, São Paulo - SP, 02350-002, Brazil', '-23.4606211', '-46.6224469', 1225, '2787520', 'AMA UBS INTEGRADA J JOAMAR', 'UBS DR JOSE TOLEDO PIZA', 'SARAMPO', 'Sarampo', 'D790072', '2020-03-02 07:57:02'),
(6848210, 'BRUNO FERNANDO RODRIGUES SANTANA', '15/01/2020', 131, 'CASA', 'Rua Sebastiana Nóbrega Donofre, 131 - Jardim Ataliba Leonel, São Paulo - SP, 02324-090, Brazil', '-23.4457763', '-46.5875289', 1651, '2787520', 'AMA UBS INTEGRADA J JOAMAR', 'UBS J JOAMAR', 'SARAMPO', 'Sarampo', 'D790072', '2020-01-15 08:44:48'),
(6848372, 'MARIA CLARA RAMOS LUZ', '07/01/2020', 806, '', 'Rua Aperibé, 806 - Parque Edu Chaves, São Paulo - SP, 02236-010, Brazil', '-23.4740139', '-46.5683712', 247, '2076896', 'HOSP SAO LUIZ GONZAGA', 'UBS PQ EDU CHAVES', 'SARAMPO', 'Sarampo', 'D790072', '2020-01-07 08:16:20'),
(6848374, 'LOANA NOVAIS PEREIRA', '08/01/2020', 480, '', 'Rua Manuel Viêira da Luz, 480 - Jardim Jacana, São Paulo - SP, Brasil', '-23.4498988', '-46.5863933', 1200, '2076896', 'HOSP SAO LUIZ GONZAGA', 'UBS J JOAMAR', 'SARAMPO', 'Sarampo', 'D790072', '2020-01-08 08:16:50'),
(6848402, 'DAVI LUCCA MACIEL SILVA', '13/01/2020', 6, 'CASA', 'Rua Hilaurentino da Silva, 6 - Jardim Joana D\'arc, São Paulo - SP, Brasil', '-23.4435395', '-46.5789424', 833, '2076896', 'HOSP SAO LUIZ GONZAGA', 'UBS J FONTALIS', 'SARAMPO', 'Sarampo', 'D790072', '2020-01-13 08:05:17'),
(6848403, 'HUGO MIRANDA SANTOS', '13/01/2020', 168, 'CASA', 'Rua Nério Brunelli, 168 - Vila Dorna, São Paulo - SP, 02322-270, Brazil', '-23.4443667', '-46.5940786', 1355, '2076896', 'HOSP SAO LUIZ GONZAGA', 'UBS J JOAMAR', 'SARAMPO', 'Sarampo', 'D790072', '2020-01-13 08:03:19'),
(6848411, 'KAMILLY SANTOS SILVA', '14/01/2020', 15, 'CASA', 'Rua São Gabriel, 15 - Vila Nova Galvão, São Paulo - SP, 02282-000, Brazil', '-23.4441877', '-46.5680853', 1624, '2076896', 'HOSP SAO LUIZ GONZAGA', 'UBS V NOVA GALVAO', 'SARAMPO', 'Sarampo', 'D790072', '2020-01-14 07:12:04'),
(6848436, 'KAIQUE LIMS SILVA', '20/01/2020', 122, '', 'Rua Arley Gilberto de Araújo, 122 - Jardim Felicidade(Zona Norte), São Paulo - SP, Brasil', '-23.4450409', '-46.577557', 268, '2076896', 'HOSP SAO LUIZ GONZAGA', 'UBS JOVA RURAL', 'SARAMPO', 'Sarampo', 'D790072', '2020-01-20 07:54:47'),
(6848446, 'NICOLAS ANTHONY MINAS COSTA', '21/01/2020', 24, 'CASA', 'Rua São Mauro Confessor, 24 - Tres Cruzes, São Paulo - SP, Brasil', '-23.4369118', '-46.5730563', 1642, '2076896', 'HOSP SAO LUIZ GONZAGA', 'UBS J FLOR DE MAIO', 'SARAMPO', 'Sarampo', 'D790072', '2020-01-21 08:04:00'),
(6848474, 'STHEFANNY AGUIAR CAETANO', '14/02/2020', 1, 'CASA', 'Carregando...', '15123487222', '1909320000', 1917, '2076896', 'HOSP SAO LUIZ GONZAGA', 'UBS J FLOR DE MAIO', 'SARAMPO', 'Sarampo', 'D790072', '2020-02-14 09:21:30'),
(6860100, 'ANNA CAROLINA MARINHO FALCAO', '14/02/2020', 3, 'CASA', 'Rua Padre Estanislau Ticner, 3 - Jardim Modelo, São Paulo - SP, 02238-120, Brazil', '-23.4678202', '-46.56730959999999', 656, '3027805', 'HOSPITAL SAN PAOLO', 'UBS PQ EDU CHAVES', 'SARAMPO', 'Sarampo', 'D790072', '2020-02-14 09:21:50'),
(6892644, 'LIZ GODINHO ROSA', '04/11/2020', 36, '', 'Rua Nino Rota, 36 - Vila Dona Augusta, São Paulo - SP, 02322-290, Brazil', '-23.4440598', '-46.5944502', 1364, '2787520', 'AMA UBS INTEGRADA J JOAMAR', 'UBS J JOAMAR', 'SARAMPO', 'Sarampo', 'D790072', '2020-11-04 06:47:22'),
(6904897, NULL, '14/01/2020', 86, 'VILA MAZZEI', 'Rua Doutor Valentim Bouças, 86 - Vila Nova Mazzei, São Paulo - SP, 02315-010, Brazil', '-23.4601377', '-46.601305', 1769, '4049985', 'UBS WAMBERTO DIAS DA COSTA', NULL, 'SARAMPO', 'Sarampo', 'D790072', '2020-01-14 07:12:29'),
(6905223, NULL, '07/01/2020', 33, '', 'Rua Pedro Marques, 33 - Jardim Joana D\'arc, São Paulo - SP, Brasil', '-23.4418857', '-46.581382700000006', 1466, '2071495', 'PS MUN SANTANA LAURO RIBAS BRAGA', NULL, 'SARAMPO', 'Sarampo', 'D790072', '2020-01-07 08:16:51'),
(6905751, 'BERNARDO MAXIMILIANO ANDRIETTA DITA', '21/02/2020', 251, 'JD LEONOR MENDES DE BARROS', 'Rua Messina, 251 - Jardim Leonor Mendes de Barros, São Paulo - SP, Brasil', '-23.4598214', '-46.60756300000001', 1295, '3027805', 'HOSPITAL SAN PAOLO', 'UBS DONA MARIQUINHA SCIASCIA', 'SARAMPO', 'Sarampo', 'D790072', '2020-02-21 08:01:13'),
(6937683, 'JADE KATHERINE CAMPOS OLIVEIRA', '11/02/2020', 88, '', 'Rua Acaituba, 88 - Jardim Modelo, São Paulo - SP, 02236-180, Brazil', '-23.4703528', '-46.572213', 37, '2076896', 'HOSP SAO LUIZ GONZAGA', 'UBS PQ EDU CHAVES', 'SARAMPO', 'Sarampo', 'D790072', '2020-02-11 08:34:53'),
(6937758, 'SAMIRA APARECIDA GONCALVES URBANO', '14/02/2020', 11, 'CASA 01', 'Rua Dionísio de Sousa, 11 - Tremembé, São Paulo - SP, 02353-060, Brazil', '-23.4541535', '-46.60210729999999', 1317, '2076896', 'HOSP SAO LUIZ GONZAGA', 'UBS DR JOSE TOLEDO PIZA', 'SARAMPO', 'Sarampo', 'D790072', '2020-02-14 09:22:31'),
(6937773, 'MARIA EDUARDA RIBEIRO CAMPOS', '21/02/2020', 677, 'CASA', 'Rua das Furnas, 677 - Tremembé, São Paulo - SP, 02324-140, Brazil', '-23.4419826', '-46.5882111', 766, '2076896', 'HOSP SAO LUIZ GONZAGA', 'UBS J JOAMAR', 'SARAMPO', 'Sarampo', 'D790072', '2020-02-21 08:01:41'),
(6937804, 'DANILO GAEL LEMOS EMANUELLA', '02/03/2020', 256, '', 'Rua Ernesto Simões Filho, 256 - Vila Nova Galvão, São Paulo - SP, 02281-130, Brazil', '-23.4494385', '-46.57276849999999', 650, '2076896', 'HOSP SAO LUIZ GONZAGA', 'UBS V NOVA GALVAO', 'SARAMPO', 'Sarampo', 'D790072', '2020-03-02 07:55:27'),
(6937821, 'MURILLO SANTOS RIBEIRO', '02/03/2020', 102, '', 'Rua Guilherme Bude, 102 - Jardim Ataliba Leonel, São Paulo - SP, 02324-010, Brazil', '-23.44732', '-46.5852976', 811, '2076896', 'HOSP SAO LUIZ GONZAGA', 'UBS J JOAMAR', 'SARAMPO', 'Sarampo', 'D790072', '2020-03-02 07:55:07'),
(6937831, 'ARTHUR BIBIANO SANTOS', '02/03/2020', 18, '', 'Rua Bom Jesus da Cachoeira, 18 - Parque Edu Chaves, São Paulo - SP, 02236-020, Brazil', '-23.4743946', '-46.5703612', 400, '2076896', 'HOSP SAO LUIZ GONZAGA', 'UBS PQ EDU CHAVES', 'SARAMPO', 'Sarampo', 'D790072', '2020-03-02 07:55:55'),
(6937842, 'LUCILIA CARDOSO MATTOS', '02/03/2020', 281, '', 'Rua Cirene de Oliveira Laet, 281 - Vila Nilo, São Paulo - SP, 02279-010, Brazil', '-23.46114859999999', '-46.578369', 533, '2076896', 'HOSP SAO LUIZ GONZAGA', 'UBS DR JOSE TOLEDO PIZA', 'SARAMPO', 'Sarampo', 'D790072', '2020-03-02 07:57:18'),
(6937888, 'ENZO DE JESUS FELICIANO', '23/06/2020', 406, 'CASA 01', 'Rua Antoninho Marmo, 406 - Vila Irmaos Arnoni, São Paulo - SP, 02374-020, Brazil', '-23.4536174', '-46.6225463', 192, '2027690', 'UBS DONA MARIQUINHA SCIASCIA', 'UBS DONA MARIQUINHA SCIASCIA', 'SARAMPO', 'Sarampo', 'D788796', '2020-06-23 08:00:29'),
(6937968, 'ICARO SANTOS DIAS', '21/02/2020', 1591, '', 'Avenida Antonelo da Messina, 1591 - Tremembé, São Paulo - SP, 02318-000, Brazil', '-23.4494342', '-46.588834', 185, '2787520', 'AMA UBS INTEGRADA J JOAMAR', 'UBS J JOAMAR', 'SARAMPO', 'Sarampo', 'D790072', '2020-02-21 08:02:22'),
(6939631, 'BEATRIZ SANTOS VAZ DE OLIVEIRA', '21/01/2020', 222, '', 'Rua Solano Trindade, 222 - Parque Ramos Freitas, São Paulo - SP, 02353-010, Brazil', '-23.451674', '-46.6037651', 1690, '2787520', 'AMA UBS INTEGRADA J JOAMAR', 'UBS V ALBERTINA DR OSVALDO MARCAL', 'SARAMPO', 'Sarampo', 'D790072', '2020-01-21 08:04:47'),
(6949941, 'IGOR CORDEIRO BATELLA DO PRADO', '23/06/2020', 93, '', 'Rua Engenheiro Joaquim Sampaio Ferraz, 93 - Vila Nova Mazzei, São Paulo - SP, 02315-040, Brazil', '-23.4593312', '-46.60159059999999', 978, '3039420', 'HOSPITAL SAO CAMILO SANTANA', 'UBS J JOAMAR', 'SARAMPO', 'Sarampo', 'D788796', '2020-06-23 08:00:12'),
(6957433, 'HENRIQUE TRAJANO DA CUNHA GONZALEZ', '02/03/2020', 14, '', 'Rua Orlando Rosa Bonfim Junior, 14 - Conjunto Habitacional Jova Rural, São Paulo - SP, Brasil', '-23.45523279999999', '-46.579103', 1393, '2078589', 'HOSPITAL E MATERNIDADE SANTA MARIA CRUZ AZUL', 'UBS JOVA RURAL', 'SARAMPO', 'Sarampo', 'D790072', '2020-03-02 07:56:14'),
(6957452, 'HENRIQUE TRAJANO DA CUNHA GONZALEZ', '20/03/2020', 14, '', 'Rua Orlando Rosa Bonfim Junior, 14 - Conjunto Habitacional Jova Rural, São Paulo - SP, Brasil', '-23.45523279999999', '-46.579103', 1393, '2078589', 'HOSPITAL E MATERNIDADE SANTA MARIA CRUZ AZUL', 'UBS JOVA RURAL', 'SARAMPO', 'Sarampo', 'D790072', '2020-03-20 07:53:03'),
(6962136, 'LUIZ MIGUEL ARAUJO DE OLIVEIRA', '11/02/2020', 8, '', 'Rua Portal II, 8 - Jardim Felicidade(Zona Norte), São Paulo - SP, Brasil', '-23.4474405', '-46.5755501', 1504, '2089777', 'HOSP NIPO BRASILEIRO', 'UBS JOVA RURAL', 'SARAMPO', 'Sarampo', 'D790072', '2020-02-11 08:35:50'),
(6976462, 'NATALIA FLORIANO NUTTI', '10/08/2020', 23, 'CASA 02', 'Rua dos João de Barro, 23 - Jardim Labitary, São Paulo - SP, Brasil', '-23.4196963', '-46.5849507', 593, '9997091', 'UPA JACANA', 'UBS JARDIM DAS PEDRAS', 'SARAMPO', 'Sarampo', 'D790072', '2020-08-10 09:06:14'),
(6978791, 'CARLA CRISTINA BATISTA', '10/08/2020', 115, 'AP182 BL04', 'Rua Josefina Arnoni, 115 - Vila Irmaos Arnoni, São Paulo - SP, 02374-050, Brazil', '-23.4573064', '-46.6206427', 1045, '3464555', 'CENTRO MEDICO PMESP', 'UBS DONA MARIQUINHA SCIASCIA', 'SARAMPO', 'Sarampo', 'D790072', '2020-08-10 09:07:42'),
(6979771, 'GUILHERME SAMPAIO DA SILVA', '10/08/2020', 4, '', 'Rua dos Colibrís da Serra, 04 - Vila Ayrosa, São Paulo - SP, Brasil', '-23.4359201', '-46.5717582', 539, '4049985', 'UBS WAMBERTO DIAS DA COSTA', 'UBS J FONTALIS', 'SARAMPO', 'Sarampo', 'D790072', '2020-08-10 09:07:27'),
(6979785, 'MARIA MAURILIO DE ASSUNCAO SILVA', '18/08/2020', 46, '', 'Rua dos João de Barro, 46 - Jardim Labitary, São Paulo - SP, Brasil', '-23.42010029999999', '-46.58465409999999', 593, '6148891', 'AMA WAMBERTO DIAS DA COSTA', 'UBS JARDIM DAS PEDRAS', 'SARAMPO', 'Sarampo', 'D790072', '2020-08-18 08:30:18'),
(7201734, 'MARIA LUISA MONTEIRO LIMA', '29/12/2020', 8, '', 'Rua Antônio José Parra Primeiro, 8 - Sítio do Piqueri, São Paulo - SP, Brasil', '-23.4478894', '-46.585147', 217, '4049985', 'UBS WAMBERTO DIAS DA COSTA', 'UBS J APUANA', 'SARAMPO', 'Sarampo', 'D790072', '2020-12-29 07:43:50');
