
-- --------------------------------------------------------

--
-- Estrutura da tabela `doencasurto`
--

CREATE TABLE `doencasurto` (
  `id` int(11) NOT NULL,
  `doencanot` varchar(100) DEFAULT NULL,
  `cid` varchar(11) DEFAULT NULL,
  `criado` datetime DEFAULT NULL,
  `usuariocad` varchar(20) DEFAULT 'sistema',
  `alterado` datetime DEFAULT NULL,
  `usuarioalt` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `doencasurto`
--

INSERT INTO `doencasurto` (`id`, `doencanot`, `cid`, `criado`, `usuariocad`, `alterado`, `usuarioalt`) VALUES
(1, 'VARICELA (SURTO)', 'B01.9', NULL, 'sistema', NULL, NULL),
(2, 'OUTROS (SURTO)', NULL, NULL, 'sistema', NULL, NULL),
(3, 'BOTULISMO (SURTO)', 'A05.1', NULL, 'sistema', NULL, NULL),
(4, 'BRUCELOSE (SURTO)', 'A23', NULL, 'sistema', NULL, NULL),
(5, 'CARBUNCULO/ANTRAZ (SURTO)', 'A22.9', NULL, 'sistema', NULL, NULL),
(6, 'CAXUMBA(PARIODITE EP.) SEM COMP.(SURTO)', 'B26.9', NULL, 'sistema', NULL, NULL),
(7, 'COLERA (SURTO)', 'A00.9', NULL, 'sistema', NULL, NULL),
(8, 'CONJUNTIVITE (SURTO)', 'H10', NULL, 'sistema', NULL, NULL),
(9, 'COQUELUCHE (SURTO)', 'A37.9', NULL, 'sistema', NULL, NULL),
(10, 'DENGUE (SURTO)', 'A90', NULL, 'sistema', NULL, NULL),
(11, 'DIARREIA E GASTROENTERITE INF. PRES. (SURTO)', 'A09', NULL, 'sistema', NULL, NULL),
(12, 'DIFTERIA (SURTO)', 'A36.9', NULL, 'sistema', NULL, NULL),
(13, 'DOENCA DE CHAGAS AGUDA (SURTO)', 'B57.1', NULL, 'sistema', NULL, NULL),
(14, 'DOENCA DE CREUTZFELDT-JACOB (SURTO)', 'A81.0', NULL, 'sistema', NULL, NULL),
(15, 'DOENCA DE MARBURG (SURTO)', 'A98.3', NULL, 'sistema', NULL, NULL),
(16, 'DOENCA PELO VIRUS EBOLA (SURTO)', 'A98.4', NULL, 'sistema', NULL, NULL),
(17, 'DOENCAS EXANTEMATICAS (SURTO)', 'B09', NULL, 'sistema', NULL, NULL),
(18, 'DOENCA AGUDA PELO ZICA VIRUS (SURTO)', 'A92.8', NULL, 'sistema', NULL, NULL),
(19, 'ESCARLATINA (SURTO)', 'A38', NULL, 'sistema', NULL, NULL),
(20, 'ESQUISTOSSOMOSE (SURTO)', 'B65.9', NULL, 'sistema', NULL, NULL),
(21, 'EVENTOS ADVERSOS POS-VACINACAO (SURTO)', 'Y59', NULL, 'sistema', NULL, NULL),
(22, 'FEBRE AMARELA (SURTO)', 'A95.9', NULL, 'sistema', NULL, NULL),
(23, 'FEBRE DO CHIKUNGUNYA (SURTO) ', 'A92.0', NULL, 'sistema', NULL, NULL),
(24, 'FEBRE DE LASSA (SURTO)', 'A96.2', NULL, 'sistema', NULL, NULL),
(25, 'FEBRE DO NILO (SURTO)', 'A92.3', NULL, 'sistema', NULL, NULL),
(26, 'FEBRE HEM. ARENAVIRUS NAO ESP (SURTO)', 'A96.9', NULL, 'sistema', NULL, NULL),
(27, 'FEBRE MACULOSA/RICKETTSIOSES (SURTO)', 'A77.9', NULL, 'sistema', NULL, NULL),
(28, 'FEBRE PURPURICA DO BRASIL (SURTO)', 'A48.4', NULL, 'sistema', NULL, NULL),
(29, 'FEBRE TIFOIDE (SURTO)', 'A01.0', NULL, 'sistema', NULL, NULL),
(30, 'FILARIOSE NAO ESPECIFICADA (SURTO)', 'B74.9', NULL, 'sistema', NULL, NULL),
(31, 'HANTAVIROSE (SURTO)', 'A98.8', NULL, 'sistema', NULL, NULL),
(32, 'HEPATITE AGUDA A (SURTO)', 'B15', NULL, 'sistema', NULL, NULL),
(33, 'HEPATITES VIRAIS (SURTO)', 'B19', NULL, 'sistema', NULL, NULL),
(34, 'INFLUENZA H. NOVO SUB. PANDEMICO (SURTO)', 'J11', NULL, 'sistema', NULL, NULL),
(35, 'INTOXICACAO EXOGENA (SURTO)', 'T65.9', NULL, 'sistema', NULL, NULL),
(36, 'LEISHMANIOSE TEGUMENTAR AMERICANA (SURTO)', 'B55.1', NULL, 'sistema', NULL, NULL),
(37, 'LEISHMANIOSE VISCERAL (SURTO)', 'B55.0', NULL, 'sistema', NULL, NULL),
(38, 'LEPTOSPIROSE (SURTO)', 'A27.9', NULL, 'sistema', NULL, NULL),
(39, 'MALARIA (SURTO)', 'B54', NULL, 'sistema', NULL, NULL),
(40, 'MENINGITE (SURTO)', 'G03.9', NULL, 'sistema', NULL, NULL),
(41, 'MORMO (SURTO)', 'A24.0', NULL, 'sistema', NULL, NULL),
(42, 'OUTRAS FEBRES VIRAIS ESP. TRANS. ART (SURTO)', 'A938', NULL, 'sistema', NULL, NULL),
(43, 'OUTRAS SINDROMES (SURTO)', 'R69.9', NULL, 'sistema', NULL, NULL),
(44, 'PARALISIA FL. AG. POLIO (SURTO)', 'A80.9', NULL, 'sistema', NULL, NULL),
(45, 'PESTE (SURTO)', 'A20.9', NULL, 'sistema', NULL, NULL),
(46, 'RAIVA HUMANA (SURTO)', 'A82.9', NULL, 'sistema', NULL, NULL),
(47, 'ROTAVIRUS (SURTO)', 'A08.0', NULL, 'sistema', NULL, NULL),
(48, 'SINDROME FEBRE HEMORRAGICA AGUDA (SURTO)', 'D69.9', NULL, 'sistema', NULL, NULL),
(49, 'SINDROME DA INSUFICIENCIA RENAL AGUDA (SURTO)', 'N19.9', NULL, 'sistema', NULL, NULL),
(50, 'SINDROME DIARREICA AGUDA', 'A08', NULL, 'sistema', NULL, NULL),
(51, 'SINDROME GRIPAL (SURTO)', 'J06', NULL, 'sistema', NULL, NULL),
(52, 'SINDROME ICTERICA AGUDA (SURTO)', 'R17', NULL, 'sistema', NULL, NULL),
(53, 'SINDROME NEUROLOGICA AGUDA (SURTO)', 'G04.3', NULL, 'sistema', NULL, NULL),
(54, 'SINDROME RESPIRATORIA AGUDA (SURTO)', 'J07', NULL, 'sistema', NULL, NULL),
(55, 'TOXOPLASMOSE (SURTO)', 'B58', NULL, 'sistema', NULL, NULL),
(56, 'TULAREMIA (SURTO)', 'A21.9', NULL, 'sistema', NULL, NULL),
(57, 'VARIOLA (SURTO)', 'B03', NULL, 'sistema', NULL, NULL),
(58, 'COVID (SURTO)', 'B34', '2021-08-23 08:55:28', 'D788796', NULL, NULL);
