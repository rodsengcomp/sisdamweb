
-- --------------------------------------------------------

--
-- Estrutura da tabela `tblsarampo`
--

CREATE TABLE `tblsarampo` (
  `nDoc` int(7) NOT NULL,
  `NomePaciente` varchar(200) DEFAULT NULL,
  `DataEntrada` varchar(10) DEFAULT NULL,
  `N` int(10) DEFAULT NULL,
  `Complemento` varchar(100) DEFAULT NULL,
  `RuaGoogle` varchar(200) DEFAULT NULL,
  `Latitude` text DEFAULT NULL,
  `Longitude` text DEFAULT NULL,
  `idRua` int(5) DEFAULT NULL,
  `CnesUnidadeNotificadora` varchar(7) DEFAULT '0000000',
  `UnidadeNotificadora` varchar(100) DEFAULT 'NAO INFORMADO',
  `ubs` varchar(100) DEFAULT NULL,
  `agravo` varchar(20) DEFAULT 'SARAMPO',
  `type` varchar(10) DEFAULT 'Sarampo',
  `usuarioAlteracao` varchar(13) DEFAULT NULL,
  `DataAlteracao` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `tblsarampo`
--

INSERT INTO `tblsarampo` (`nDoc`, `NomePaciente`, `DataEntrada`, `N`, `Complemento`, `RuaGoogle`, `Latitude`, `Longitude`, `idRua`, `CnesUnidadeNotificadora`, `UnidadeNotificadora`, `ubs`, `agravo`, `type`, `usuarioAlteracao`, `DataAlteracao`) VALUES
(8685037, NULL, '24/03/2022', 64, '', 'Rua Antônio Joaquim de Oliveira, 64 - Jardim Virginia Bianca, São Paulo - SP, 02356-020, Brazil', '-23.4504891', '-46.61105939999999', 1587, '2027275', 'UBS V ALBERTINA DR OSVALDO MARCAL', NULL, 'SARAMPO', 'Sarampo', 'D788796', '2022-03-24 10:36:52'),
(8685080, 'KAYNA VICTOR PAULINO SOARES', '23/05/2022', 49, '', 'Rua Bela Vista, 49 - Jardim Joana D\'arc, São Paulo - SP, Brasil', '-23.4445912', '-46.5800948', 350, '9339833', 'UBS JOVA RURAL', 'UBS JOVA RURAL', 'SARAMPO', 'Sarampo', 'D790072', '2022-05-23 11:18:20');
