
-- --------------------------------------------------------

--
-- Estrutura da tabela `coque_ial`
--

CREATE TABLE `coque_ial` (
  `id` int(11) NOT NULL,
  `Requisição` bigint(12) DEFAULT NULL,
  `Paciente` varchar(43) DEFAULT NULL,
  `CNS` varchar(15) DEFAULT NULL,
  `CPF` varchar(15) DEFAULT NULL,
  `Setor` varchar(7) DEFAULT NULL,
  `Bancada` varchar(9) DEFAULT NULL,
  `Mun. Residência` varchar(22) DEFAULT NULL,
  `UF Residência` varchar(2) DEFAULT NULL,
  `Requisitante` varchar(60) DEFAULT NULL,
  `Mun. Requisitante` varchar(9) DEFAULT NULL,
  `Exame` varchar(33) DEFAULT NULL,
  `Metodo` varchar(21) DEFAULT NULL,
  `Material` varchar(33) DEFAULT NULL,
  `Cód. Amostra` int(6) DEFAULT NULL,
  `Amostra` int(1) DEFAULT NULL,
  `Restrição` varchar(10) DEFAULT NULL,
  `Labotório Cadastro` varchar(32) DEFAULT NULL,
  `Dt. Cadastro` varchar(16) DEFAULT NULL,
  `Dt. Recebimento` varchar(16) DEFAULT NULL,
  `Dt. Liberação` varchar(16) DEFAULT NULL,
  `Tempo Liberação` varchar(3) DEFAULT NULL,
  `Labotório Executor` varchar(29) DEFAULT NULL,
  `Status Exame` varchar(26) DEFAULT NULL,
  `Resultado` varchar(22) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `coque_ial`
--

INSERT INTO `coque_ial` (`id`, `Requisição`, `Paciente`, `CNS`, `CPF`, `Setor`, `Bancada`, `Mun. Residência`, `UF Residência`, `Requisitante`, `Mun. Requisitante`, `Exame`, `Metodo`, `Material`, `Cód. Amostra`, `Amostra`, `Restrição`, `Labotório Cadastro`, `Dt. Cadastro`, `Dt. Recebimento`, `Dt. Liberação`, `Tempo Liberação`, `Labotório Executor`, `Status Exame`, `Resultado`) VALUES
(1, 220106000382, 'ANTHONY JOSE FERREIRA GOMES', '898006258313088', '59700002802', 'CB/NDEI', 'Coqueluch', 'SAO PAULO', 'SP', 'HOSPITAL INFANTIL CANDIDO FONTOURA SAO PAULO', 'SAO PAULO', 'Coqueluche, Detecção de Bordetell', 'Cultura', 'Secreção nasofaríngea', 355476835, 0, '', 'SAO PAULO - LABORATORIO LOCAL 01', '03/01/2022 11:44', '03/01/2022 14:26', '18/01/2022 09:36', '15', 'Instituto Adolfo Lutz Central', 'Resultado Liberado', 'Não houve crescimento '),
(2, 220106014248, 'PAULO GASPAR ROMANO', '898006268977159', '59866727807', 'CB/NDEI', 'Coqueluch', 'SAO PAULO', 'SP', 'HOSPITAL DA CRIANCA', 'SAO PAULO', 'Coqueluche, Detecção de Bordetell', 'Cultura', 'Secreção nasofaríngea', 355997447, 1, '', 'SAO PAULO - LABORATORIO LOCAL 01', '28/01/2022 10:47', '28/01/2022 16:03', '11/02/2022 09:09', '14', 'Instituto Adolfo Lutz Central', 'Resultado Liberado', 'Não houve crescimento '),
(3, 220106008247, 'MAITE HELOISA DA SILVA', '700604437888366', '', 'CB/NDEI', 'Coqueluch', 'SAO PAULO', 'SP', 'CONJUNTO HOSPITALAR DO MANDAQUI SAO PAULO', 'SAO PAULO', 'Coqueluche, Detecção de Bordetell', 'Cultura', 'Swab Nasofaringe', 355759296, 1, '', 'SAO PAULO - LABORATORIO LOCAL 01', '17/01/2022 15:58', '18/01/2022 09:51', '01/02/2022 07:42', '14', 'Instituto Adolfo Lutz Central', 'Resultado Liberado', 'Não houve crescimento '),
(4, 220106019968, 'JOSE LUCAS TAVARES FERNANDES', '898006178945487', '58169820871', 'CB/NDEI', 'Coqueluch', 'SAO PAULO', 'SP', 'HC DA FMUSP HOSPITAL DAS CLINICAS SAO PAULO', 'SAO PAULO', 'Coqueluche, Detecção de Bordetell', 'Cultura', 'Secreção', 356193048, 1, '', 'SAO PAULO - LABORATORIO LOCAL 01', '25/02/2022 10:54', '25/02/2022 13:42', '09/03/2022 10:43', '12', 'Instituto Adolfo Lutz Central', 'Resultado Liberado', 'Não houve crescimento '),
(5, 220106018716, 'ALICE AMORA DOS SANTOS SILVA', '898006275334322', '59996926877', 'CB/NDEI', 'Coqueluch', 'SAO PAULO', 'SP', 'HOSPITAL SEPACO', 'SAO PAULO', 'Coqueluche, Detecção de Bordetell', 'Cultura', 'Secreção nasofaríngea', 356160372, 1, '', 'SAO PAULO - LABORATORIO LOCAL 01', '18/02/2022 10:55', '18/02/2022 13:37', '04/03/2022 10:48', '14', 'Instituto Adolfo Lutz Central', 'Resultado Liberado', 'Não houve crescimento '),
(6, 220106015233, 'RN LAURA COVARRUBIAS', '702509330921538', '', 'CB/NDEI', 'Coqueluch', 'SAO PAULO', 'SP', 'HOSP MUN VER JOSE STOROPOLLI', 'SAO PAULO', 'Coqueluche, Detecção de Bordetell', 'Cultura', 'Swab naso-orofaríngeo', 356041346, 1, '', 'SAO PAULO - LABORATORIO LOCAL 01', '01/02/2022 14:15', '02/02/2022 11:37', '11/02/2022 09:09', '9', 'Instituto Adolfo Lutz Central', 'Resultado Liberado', 'Não houve crescimento '),
(7, 220106016517, 'DAVI LUCCA INACIO DA SILVA', '704004859364861', '59116666852', 'CB/NDEI', 'Coqueluch', 'SAO PAULO', 'SP', 'UBS CIDADE PEDRO JOSE NUNES', 'SAO PAULO', 'Coqueluche, Detecção de Bordetell', 'Cultura', 'Coriza', 356089731, 1, '', 'SAO PAULO - LABORATORIO LOCAL 01', '07/02/2022 16:24', '08/02/2022 10:52', '22/02/2022 08:35', '14', 'Instituto Adolfo Lutz Central', 'Resultado Liberado', 'Não houve crescimento '),
(8, 220106015530, 'DAVI FERREIRA LARCHER', '', '59858004826', 'CB/NDEI', 'Coqueluch', 'SAO PAULO', 'SP', 'HOSPITAL INFANTIL SABARA', 'SAO PAULO', 'Coqueluche, Detecção de Bordetell', 'Cultura', 'Swab de orofaringe', 356053213, 1, '', 'SAO PAULO - LABORATORIO LOCAL 01', '02/02/2022 13:51', '02/02/2022 14:41', '17/02/2022 15:02', '15', 'Instituto Adolfo Lutz Central', 'Resultado Liberado', 'Não houve crescimento '),
(9, 220106022422, 'DAVI LEANDRO LIMA NASCIMENTO', '709008891037212', '', 'CB/NDEI', 'Coqueluch', 'SAO PAULO', 'SP', 'UBS JD D ABRIL', 'SAO PAULO', 'Coqueluche, Detecção de Bordetell', 'Cultura', 'Secreção nasofaríngea', 356258001, 1, '', 'SAO PAULO - LABORATORIO LOCAL 01', '18/03/2022 08:12', '', '', '', '', 'Aguardando Triagem', ' \r'),
(10, 220106021913, 'EDUARDO BRANDINO DE BARROS', '700000813639705', '', 'CB/NDEI', 'Coqueluch', 'SAO PAULO', 'SP', 'HOSP MUN CIDADE TIRADENTES CARMEN PRUDENTE', 'SAO PAULO', 'Coqueluche, Detecção de Bordetell', 'Cultura', 'Swab Nasofaringe', 356243893, 0, '', 'SAO PAULO - LABORATORIO LOCAL 01', '15/03/2022 07:44', '15/03/2022 14:18', '', '', '', 'Exame em Análise', ' \r'),
(11, 220106021271, 'ANTHONY GAEL DOS SANTOS SABINO', '898006276940838', '60067254870', 'CB/NDEI', 'Coqueluch', 'SAO PAULO', 'SP', 'HOSPITAL GERAL SANTA MARCELINA DE ITAIM PAULISTA SAO PAULO', 'SAO PAULO', 'Coqueluche, Detecção de Bordetell', 'Cultura', 'Swab Nasofaringe', 356227616, 1, '', 'SAO PAULO - LABORATORIO LOCAL 01', '09/03/2022 13:04', '10/03/2022 10:42', '', '', '', 'Exame em Análise', ' \r'),
(12, 220106022108, 'HEITOR GABRIEL CHAGAS DOS SANTOS', '898006008145005', '57765700855', 'CB/NDEI', 'Coqueluch', 'SAO PAULO', 'SP', 'HC DA FMUSP HOSPITAL DAS CLINICAS SAO PAULO', 'SAO PAULO', 'Coqueluche, Detecção de Bordetell', 'Cultura', 'Secreção', 356250432, 1, '', 'SAO PAULO - LABORATORIO LOCAL 01', '16/03/2022 11:00', '16/03/2022 13:56', '', '', '', 'Exame em Análise', ' \r'),
(13, 220106021127, 'JENILSON RODRIGUES DOS SANTOS', '700209952802725', '18583841845', 'CB/NDEI', 'Coqueluch', 'GUARULHOS', 'SP', 'PS MUN SANTANA LAURO RIBAS BRAGA', 'SAO PAULO', 'Coqueluche, Detecção de Bordetell', 'Cultura', 'Secreção nasofaríngea', 356223199, 1, '', 'SAO PAULO - LABORATORIO LOCAL 01', '08/03/2022 13:41', '08/03/2022 15:01', '16/03/2022 09:30', '8', 'Instituto Adolfo Lutz Central', 'Resultado Liberado', 'Cultura contaminada \r');
