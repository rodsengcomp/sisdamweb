
-- --------------------------------------------------------

--
-- Estrutura da tabela `origem`
--

CREATE TABLE `origem` (
  `id_origem` int(11) NOT NULL,
  `nm_origem` text NOT NULL,
  `criado` text NOT NULL,
  `data_criado` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `origem`
--

INSERT INTO `origem` (`id_origem`, `nm_origem`, `criado`, `data_criado`) VALUES
(1, 'CCZ PLANTAO', 'D788796', '2022-09-05 13:10:14'),
(2, 'UVIS JACANA', 'D788796', '2022-09-05 13:10:22');
