
-- --------------------------------------------------------

--
-- Estrutura da tabela `sv21`
--

CREATE TABLE `sv21` (
  `id` int(4) NOT NULL,
  `sinan` varchar(7) DEFAULT NULL,
  `protocolo` varchar(13) DEFAULT NULL,
  `datanot` varchar(10) DEFAULT NULL,
  `agravo` varchar(39) DEFAULT NULL,
  `nome` varchar(60) DEFAULT NULL,
  `idade` varchar(4) DEFAULT NULL,
  `sexo` varchar(1) DEFAULT NULL,
  `dataentrada` varchar(10) DEFAULT NULL,
  `se` varchar(4) DEFAULT NULL,
  `data1sint` varchar(10) DEFAULT NULL,
  `localate` varchar(60) DEFAULT NULL,
  `tel` varchar(15) DEFAULT NULL,
  `num` varchar(5) DEFAULT NULL,
  `comp` varchar(50) DEFAULT NULL,
  `da` varchar(2) DEFAULT NULL,
  `cep` varchar(9) DEFAULT NULL,
  `log` varchar(15) DEFAULT NULL,
  `rua` varchar(82) DEFAULT NULL,
  `bairro` varchar(45) DEFAULT NULL,
  `localvd` varchar(33) DEFAULT NULL,
  `suvis` varchar(27) DEFAULT NULL,
  `cidade` varchar(21) DEFAULT NULL,
  `idrua` varchar(6) DEFAULT NULL,
  `dataobito` varchar(10) DEFAULT NULL,
  `criado` varchar(19) DEFAULT NULL,
  `latsv2` varchar(19) DEFAULT NULL,
  `longsv2` varchar(23) DEFAULT NULL,
  `usuariocad` varchar(17) DEFAULT NULL,
  `alterado` varchar(19) DEFAULT NULL,
  `usuarioalt` varchar(7) DEFAULT NULL,
  `ocorrencia` varchar(12) DEFAULT NULL,
  `tipo` varchar(11) DEFAULT NULL,
  `lixeira` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
