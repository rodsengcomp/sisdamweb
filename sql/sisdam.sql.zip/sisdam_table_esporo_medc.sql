
-- --------------------------------------------------------

--
-- Estrutura da tabela `esporo_medc`
--

CREATE TABLE `esporo_medc` (
  `id_med_esp` int(11) NOT NULL,
  `nm_mdc_esp_an` text NOT NULL,
  `criado` text NOT NULL,
  `data_criado` timestamp NOT NULL DEFAULT current_timestamp(),
  `alterado` text NOT NULL,
  `data_alterado` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `esporo_medc`
--

INSERT INTO `esporo_medc` (`id_med_esp`, `nm_mdc_esp_an`, `criado`, `data_criado`, `alterado`, `data_alterado`) VALUES
(1, 'ITRACONAZOL', 'D788796', '2022-08-02 17:18:42', '', '');
