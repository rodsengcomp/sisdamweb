
-- --------------------------------------------------------

--
-- Estrutura da tabela `index_config`
--

CREATE TABLE `index_config` (
  `id_index` int(11) NOT NULL,
  `src_car_image_1` varchar(100) NOT NULL DEFAULT 'data:image/gif;base64,R0lGODlhAQABAIAAAHd3dwAAACH5BAAAAAAALAAAAAABAAEAAAICRAEAOw==',
  `title_car_1` varchar(100) NOT NULL DEFAULT 'Inovação',
  `p_car_1` varchar(300) NOT NULL DEFAULT 'A cada dia nos aprimoramos na criação de um sistema rápido e integrado para facilitar nosso trabalho.Sempre inovando com ferramentas gratuitas de qualidade e facil acesso, em busca do melhor "Uvis Jaçanã-Tremembé".',
  `style_col_text_1` varchar(100) NOT NULL DEFAULT 'text-shadow: 2px 2px 6px rgba(0, 78, 48, 1);',
  `src_car_image_2` varchar(100) NOT NULL DEFAULT 'data:image/gif;base64,R0lGODlhAQABAIAAAHd3dwAAACH5BAAAAAAALAAAAAABAAEAAAICRAEAOw==',
  `title_car_2` varchar(100) NOT NULL DEFAULT 'Compromisso',
  `p_car_2` varchar(300) NOT NULL DEFAULT 'É importante o empenho na busca por ferramentas que cada vez venham a atender melhor a demanda de serviço.Buscamos tecnologias capazes de superar até mesmo nossas expectaivas.',
  `style_col_text_2` varchar(100) NOT NULL DEFAULT 'text-shadow: 2px 2px 6px rgba(186, 78, 48, 1);',
  `src_car_image_3` varchar(100) NOT NULL DEFAULT 'data:image/gif;base64,R0lGODlhAQABAIAAAHd3dwAAACH5BAAAAAAALAAAAAABAAEAAAICRAEAOw==',
  `title_car_3` varchar(100) NOT NULL DEFAULT 'Qualidade',
  `p_car_3` varchar(300) NOT NULL DEFAULT 'Sempre pensando em qualidade no serviço prestado e excelência nos sistemas criados.Uma equipe de trabalho que não se cansa de buscar a melhoria no processamento e armazenamento de dados.',
  `style_col_text_3` varchar(100) NOT NULL DEFAULT 'text-shadow: 2px 2px 6px rgba(184, 233, 58, 0.9);',
  `uvis_index` varchar(100) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `index_config`
--

INSERT INTO `index_config` (`id_index`, `src_car_image_1`, `title_car_1`, `p_car_1`, `style_col_text_1`, `src_car_image_2`, `title_car_2`, `p_car_2`, `style_col_text_2`, `src_car_image_3`, `title_car_3`, `p_car_3`, `style_col_text_3`, `uvis_index`) VALUES
(1, 'imagens/carroussel/setembro-amarelo-1.png', 'Inovação', 'A cada dia nos aprimoramos na criação de um sistema rápido e integrado para facilitar nosso trabalho.Sempre inovando com ferramentas gratuitas de qualidade e facil acesso, em busca do melhor \"Uvis Jaçanã-Tremembé\".', 'text-shadow: 2px 2px 6px rgba(186, 78, 48, 1);', 'imagens/carroussel/corrego1.png', 'Compromisso', 'É importante o empenho na busca por ferramentas que cada vez venham a atender melhor a demanda de serviço.Buscamos tecnologias capazes de superar até mesmo nossas expectaivas.', 'text-shadow: 2px 2px 6px rgba(186, 78, 48, 1);', 'data:image/gif;base64,R0lGODlhAQABAIAAAHd3dwAAACH5BAAAAAAALAAAAAABAAEAAAICRAEAOw==', 'Qualidade', 'Sempre pensando em qualidade no serviço prestado e excelência nos sistemas criados.Uma equipe de trabalho que não se cansa de buscar a melhoria no processamento e armazenamento de dados.', 'text-shadow: 2px 2px 6px rgba(184, 233, 58, 0.9);', '1');
