
-- --------------------------------------------------------

--
-- Estrutura da tabela `tblchiku_2021`
--

CREATE TABLE `tblchiku_2021` (
  `DataEntrada` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `nDoc` int(7) DEFAULT NULL,
  `NomeSolicitante` varchar(100) CHARACTER SET utf8 NOT NULL,
  `ResultadoIAL` varchar(30) CHARACTER SET utf8 DEFAULT 'Exame Nao Realizado',
  `Impressao` int(2) DEFAULT 0,
  `Descarte` int(2) DEFAULT 0,
  `DataAlteracao` datetime DEFAULT current_timestamp(),
  `TelefoneFixo` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `Ddd` varchar(4) CHARACTER SET utf8 NOT NULL DEFAULT '(11)',
  `Da` int(2) DEFAULT NULL,
  `Setor1` int(4) DEFAULT NULL,
  `Cep1` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
  `Logradouro` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `Endereco1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `N` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `Complemento` varchar(40) CHARACTER SET utf8 DEFAULT NULL,
  `Bairro1` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `UBS1` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `PgGuia1` varchar(7) CHARACTER SET utf8 DEFAULT NULL,
  `Observacoes` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `DataBloqueio` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `DataNeb` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `Data1Sintomas` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `Se1Sintomas` int(6) DEFAULT NULL,
  `DataColeta` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `DataResultado` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `AutoctoneImportado` varchar(1) CHARACTER SET utf8 DEFAULT NULL,
  `LPICidade` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `LpiEstado` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `Fechamento` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `UnidadeNotificadora` varchar(58) CHARACTER SET utf8 DEFAULT NULL,
  `usuarioExame` varchar(13) CHARACTER SET utf8 DEFAULT NULL,
  `DataAlteracaoExame` varchar(19) CHARACTER SET utf8 DEFAULT NULL,
  `usuarioAlteracao` varchar(13) CHARACTER SET utf8 DEFAULT NULL,
  `DataNotificacao` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `SeDataNotificacao` int(6) DEFAULT NULL,
  `DataNascimento` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `DataObito` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `CnesUnidadeNotificadora` int(7) DEFAULT NULL,
  `usuarioLer` varchar(13) CHARACTER SET utf8 DEFAULT NULL,
  `DataLer` varchar(19) CHARACTER SET utf8 DEFAULT NULL,
  `Latitude` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `Longitude` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `RuaGoogle` varchar(67) CHARACTER SET utf8 DEFAULT NULL,
  `idRua` varchar(4) CHARACTER SET utf8 DEFAULT NULL,
  `type` varchar(15) CHARACTER SET utf8 NOT NULL DEFAULT 'Chikungunya',
  `agravo` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT 'CHIKUNGUNYA',
  `ResultadoTr` varchar(19) COLLATE latin1_general_ci NOT NULL DEFAULT 'Exame Nao Realizado'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci ROW_FORMAT=COMPACT;

--
-- Extraindo dados da tabela `tblchiku_2021`
--

INSERT INTO `tblchiku_2021` (`DataEntrada`, `nDoc`, `NomeSolicitante`, `ResultadoIAL`, `Impressao`, `Descarte`, `DataAlteracao`, `TelefoneFixo`, `Ddd`, `Da`, `Setor1`, `Cep1`, `Logradouro`, `Endereco1`, `N`, `Complemento`, `Bairro1`, `UBS1`, `PgGuia1`, `Observacoes`, `DataBloqueio`, `DataNeb`, `Data1Sintomas`, `Se1Sintomas`, `DataColeta`, `DataResultado`, `AutoctoneImportado`, `LPICidade`, `LpiEstado`, `Fechamento`, `UnidadeNotificadora`, `usuarioExame`, `DataAlteracaoExame`, `usuarioAlteracao`, `DataNotificacao`, `SeDataNotificacao`, `DataNascimento`, `DataObito`, `CnesUnidadeNotificadora`, `usuarioLer`, `DataLer`, `Latitude`, `Longitude`, `RuaGoogle`, `idRua`, `type`, `agravo`, `ResultadoTr`) VALUES
('11/01/2021', 7251677, 'LUCAS CARVALHO DE SA DA SILVA', 'Exame Nao Realizado', 1, 0, '2021-01-11 07:40:25', '982279210', '11', 83, 8306, '02324-140', 'ESTRADA', 'FURNAS', '510', 'CASA 02', 'FURNAS', 'UBS J JOAMAR', '14-Z10', NULL, '11/01/2021', '', '05/01/2021', 202101, NULL, NULL, NULL, NULL, NULL, NULL, 'CONJUNTO HOSPITALAR DO MANDAQUI SAO PAULO', NULL, NULL, 'D790072', '07/01/2021', 202101, '01/12/2010', NULL, 2077574, 'D790072', '2021-01-11 07:42:51', '-23.442025', '-46.5880308', 'Rua das Furnas, 510 - Tremembé, São Paulo - SP, 02324-140, Brazil', '766', 'Chikungunya', 'CHIKUNGUNYA', 'Exame Nao Realizado'),
('21/06/2021', 6197334, 'MARCOLINA LEMOS ALVES', 'Exame Nao Realizado', 0, 0, '2021-06-21 08:42:26', '977040861', '11', 38, 3812, '02281-227', 'RUA', 'JOAO MENDES ARAUJO *', '06', '', 'CONJ.HAB.JOVA RURAL', 'UBS JOVA RURAL', '15-H21', NULL, NULL, NULL, '01/06/2021', 202122, NULL, NULL, NULL, NULL, NULL, NULL, 'COMPLEXO HOSPITALAR PADRE BENTO DE GUARULHOS', NULL, NULL, 'D788796', '07/06/2021', 202123, '09/02/1947', NULL, 2079410, NULL, NULL, '-23.4523838', '-46.5797339', 'Rua João Mendes Araújo, 6 - Conjunto Habitacional Jova Rural, São P', '962', 'Chikungunya', 'CHIKUNGUNYA', 'Exame Nao Realizado'),
('31/05/2021', 7435011, 'MARIA CLARA MELLO DA SILVA', 'Exame Nao Realizado', 0, 0, '2021-05-31 10:21:36', '', '', 38, 3804, '02238-110', 'RUA', 'GABRIEL FIGUEIRAS', '192', '', 'JARDIM CABUCU', 'UBS PQ EDU CHAVES', '44-B10', NULL, NULL, NULL, '25/04/2021', 202117, NULL, NULL, NULL, NULL, NULL, NULL, 'HOSPITAL MUNICIPAL DA CRIANCA E DO ADOLESCENTE HMCA', NULL, NULL, 'D790072', '29/04/2021', 202117, '18/04/2013', NULL, 2080427, NULL, NULL, '-23.4674392', '-46.566937', 'Rua Gabriel Filgueiras, 192 - Jardim Modelo, São Paulo - SP, 02238-', '768', 'Chikungunya', 'CHIKUNGUNYA', 'Exame Nao Realizado'),
('26/07/2021', 7290890, 'MARIA JOSE DE SOUZA ALVES', 'Exame Nao Realizado', 1, 0, '2021-07-26 09:12:51', '987580643', '11', 83, 8301, '02327-110', 'RUA', 'AIRES FERNANDES PERNA', '13', 'CASA', 'TREMEMBE', 'UBS J FONTALIS', 'A80-C25', NULL, '25/08/2021', '', '19/06/2021', 202124, NULL, NULL, NULL, NULL, NULL, NULL, 'HC DA FMUSP HOSPITAL DAS CLINICAS SAO PAULO', NULL, NULL, 'D790072', '21/07/2021', 202129, '19/01/1975', NULL, 2078015, 'D784549', '2021-08-25 14:10:52', '-23.4592041', '-46.6238835', 'Rua Leonel Fernandes, 13 - Tremembé, São Paulo - SP, 02372-060, Bra', '64', 'Chikungunya', 'CHIKUNGUNYA', 'Exame Nao Realizado'),
('28/10/2021', 7441490, 'RICK VINNICIUS DA SILVA', 'Exame Nao Realizado', 0, 0, '2021-10-28 08:18:47', '959629676', '11', 38, 3804, '02238-210', 'RUA', 'JAN MONET', '46', '', 'JARDIM CABUCU', 'UBS PQ EDU CHAVES', '44-A08', NULL, NULL, NULL, '18/07/2021', 202129, NULL, NULL, NULL, NULL, NULL, NULL, 'COMPLEXO HOSPITALAR PADRE BENTO DE GUARULHOS', NULL, NULL, 'D790072', '19/07/2021', 202129, '09/11/1997', NULL, 2079410, NULL, NULL, '-23.4646204', '-46.5688591', 'Rua Jan Monet, 46 - Jardim Modelo, São Paulo - SP, 02238-210, Brazi', '911', 'Chikungunya', 'CHIKUNGUNYA', 'Exame Nao Realizado'),
('08/07/2021', 6990529, 'VERA LUCIA DE LOURDES SILVA', 'Exame Nao Realizado', 0, 0, '2021-07-08 08:25:01', '966683166', '11', 83, 8317, '02306-004', 'AVENIDA', 'SEZEFREDO FAGUNDES, CEL. (3232 AO 5500 PAR E IMPAR)', '5169', 'APTO 14 BL E', 'TREMEMBE', 'UBS JARDIM DAS PEDRAS', '', NULL, NULL, NULL, '14/05/2021', 202119, NULL, NULL, NULL, NULL, NULL, NULL, 'HOSP DO SERV PUB MUNICIPAL HSPM', NULL, NULL, 'D790072', '14/06/2021', 202124, '13/08/1959', NULL, 2752077, NULL, NULL, '-23.4370117', '-46.5928879', 'Avenida Coronel Sezefredo Fagundes, 5169 - Tremembé, São Paulo - SP', '1676', 'Chikungunya', 'CHIKUNGUNYA', 'Exame Nao Realizado');
