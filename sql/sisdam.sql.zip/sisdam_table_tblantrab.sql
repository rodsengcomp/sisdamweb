
-- --------------------------------------------------------

--
-- Estrutura da tabela `tblantrab`
--

CREATE TABLE `tblantrab` (
  `id` int(11) NOT NULL,
  `data_entrada` varchar(10) DEFAULT NULL,
  `num_sinan` varchar(7) DEFAULT NULL,
  `da` varchar(2) DEFAULT NULL,
  `setor` varchar(4) DEFAULT NULL,
  `cep` varchar(9) DEFAULT NULL,
  `log` varchar(50) DEFAULT NULL,
  `rua` varchar(100) DEFAULT NULL,
  `num` varchar(12) DEFAULT NULL,
  `comp` varchar(50) DEFAULT NULL,
  `bairro` varchar(50) DEFAULT NULL,
  `ubs` varchar(60) DEFAULT NULL,
  `un_not` varchar(100) DEFAULT NULL,
  `usuario_ler` varchar(13) DEFAULT NULL,
  `data_ler` varchar(19) DEFAULT NULL,
  `impresso` int(2) NOT NULL DEFAULT 0,
  `descarte` varchar(2) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `tblantrab`
--

INSERT INTO `tblantrab` (`id`, `data_entrada`, `num_sinan`, `da`, `setor`, `cep`, `log`, `rua`, `num`, `comp`, `bairro`, `ubs`, `un_not`, `usuario_ler`, `data_ler`, `impresso`, `descarte`) VALUES
(1, '17/02/2021', '2201202', '38', '3808', '02375-050', 'RUA', 'TESTE UM ANTI RABICA', '2005', 'PERTO DA BIBA DO WALLACE', 'ESSE MESMO', 'UBS DOS MANO', 'HOSP VEM QUE TEM', 'D788796', '2021-01-06 08:27:46', 0, '0');
