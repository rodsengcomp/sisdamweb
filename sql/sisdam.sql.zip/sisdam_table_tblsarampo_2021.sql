
-- --------------------------------------------------------

--
-- Estrutura da tabela `tblsarampo_2021`
--

CREATE TABLE `tblsarampo_2021` (
  `nDoc` int(7) NOT NULL,
  `NomePaciente` varchar(200) DEFAULT NULL,
  `DataEntrada` varchar(10) DEFAULT NULL,
  `N` int(10) DEFAULT NULL,
  `Complemento` varchar(100) DEFAULT NULL,
  `RuaGoogle` varchar(200) DEFAULT NULL,
  `Latitude` text DEFAULT NULL,
  `Longitude` text DEFAULT NULL,
  `idRua` int(5) DEFAULT NULL,
  `CnesUnidadeNotificadora` varchar(7) DEFAULT '0000000',
  `UnidadeNotificadora` varchar(100) DEFAULT 'NAO INFORMADO',
  `ubs` varchar(100) DEFAULT NULL,
  `agravo` varchar(20) DEFAULT 'SARAMPO',
  `type` varchar(10) DEFAULT 'Sarampo',
  `usuarioAlteracao` varchar(13) DEFAULT NULL,
  `DataAlteracao` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `tblsarampo_2021`
--

INSERT INTO `tblsarampo_2021` (`nDoc`, `NomePaciente`, `DataEntrada`, `N`, `Complemento`, `RuaGoogle`, `Latitude`, `Longitude`, `idRua`, `CnesUnidadeNotificadora`, `UnidadeNotificadora`, `ubs`, `agravo`, `type`, `usuarioAlteracao`, `DataAlteracao`) VALUES
(7185934, 'KAIQUE SAMUEL GIANQUITO DE SOUZA', '24/05/2021', 28, 'CASA 04', 'Rua Onídio Barbosa de Souza, 28 - Jardim Felicidade(Zona Norte), São Paulo - SP, Brasil', '-23.4448912', '-46.5787329', 1388, '9339833', 'UBS JOVA RURAL', 'UBS JOVA RURAL', 'SARAMPO', 'Sarampo', 'D790072', '2021-05-24 08:12:41'),
(7251679, NULL, '22/02/2021', 510, 'CASA 2', 'Rua das Furnas, 510 - Tremembé, São Paulo - SP, 02324-140, Brazil', '-23.442025', '-46.5880308', 766, '2077574', 'CONJUNTO HOSPITALAR DO MANDAQUI SAO PAULO', NULL, 'SARAMPO', 'Sarampo', 'D790072', '2021-02-22 07:33:50'),
(7302050, NULL, '24/05/2021', 95, 'CASA DE ABRIGO', 'Rua Regina Iris, 95 - Vila Nova Mazzei, São Paulo - SP, 02315-150, Brazil', '-23.45909610000001', '-46.59844069999999', 1545, '2077574', 'CONJUNTO HOSPITALAR DO MANDAQUI SAO PAULO', NULL, 'SARAMPO', 'Sarampo', 'D790072', '2021-05-24 08:13:22'),
(7302208, 'ARTHUR ALVES BATISTA', '24/05/2021', 3, '', 'Rua das Flôres, 3 - Jardim Portal I e II, São Paulo - SP, Brasil', '-23.4412416', '-46.57323259999999', 717, '4049985', 'UBS WAMBERTO DIAS DA COSTA', 'UBS DR JOSE TOLEDO PIZA', 'SARAMPO', 'Sarampo', 'D790072', '2021-05-24 08:13:08'),
(7302220, NULL, '04/05/2021', 6, '', 'Rua Montenegro, 6 - Jardim Felicidade(Zona Norte), São Paulo - SP, Brasil', '-23.4457248', '-46.57724890000001', 1327, '4049985', 'UBS WAMBERTO DIAS DA COSTA', NULL, 'SARAMPO', 'Sarampo', 'D790072', '2021-05-04 10:32:20'),
(7375169, 'ISABELA CORREA VIANNA', '17/09/2021', 187, 'AP 14 BL 06', 'Rua Josefina Arnoni, 187 - Vila Irmaos Arnoni, São Paulo - SP, 02374-050, Brazil', '-23.4565155', '-46.6207506', 1045, '2080818', 'HOSP SAMARITANO', 'UBS DONA MARIQUINHA SCIASCIA', 'SARAMPO', 'Sarampo', 'D790072', '2021-09-17 07:48:29');
