
-- --------------------------------------------------------

--
-- Estrutura da tabela `ocorrenciasurto`
--

CREATE TABLE `ocorrenciasurto` (
  `id` int(11) NOT NULL,
  `localsurto` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `ocorrenciasurto`
--

INSERT INTO `ocorrenciasurto` (`id`, `localsurto`) VALUES
(1, 'RESIDENCIA'),
(2, 'ASILO'),
(3, 'HOSPITAL/UBS'),
(4, 'CASOS DISPERSOS EM MAIS DE UM MUNICIPIO'),
(5, 'OUTRAS INSTITUICOES(ALOJAMENTO/TRABALHO)'),
(6, 'CASOS DISPERSOS NO BAIRRO'),
(7, 'OUTROS'),
(8, 'RESTAURANTE/PADARIA'),
(9, 'CASOS DISPERSOS PELO MUNICIPIO'),
(10, 'CRECHE/ESCOLA'),
(11, 'EVENTOS');
