
-- --------------------------------------------------------

--
-- Estrutura da tabela `tbllepto`
--

CREATE TABLE `tbllepto` (
  `DataEntrada` varchar(10) DEFAULT NULL,
  `nDoc` varchar(7) NOT NULL,
  `NomeSolicitante` varchar(43) DEFAULT NULL,
  `TelefoneFixo` varchar(9) DEFAULT NULL,
  `Ddd` varchar(4) NOT NULL DEFAULT '(11)',
  `Da` varchar(2) DEFAULT NULL,
  `Setor1` varchar(4) DEFAULT NULL,
  `Cep1` varchar(9) DEFAULT NULL,
  `Logradouro` varchar(15) DEFAULT NULL,
  `Endereco1` varchar(83) DEFAULT NULL,
  `N` varchar(6) DEFAULT NULL,
  `Complemento` varchar(30) DEFAULT NULL,
  `Bairro1` varchar(30) DEFAULT NULL,
  `UBS1` varchar(33) DEFAULT NULL,
  `PgGuia1` varchar(7) DEFAULT NULL,
  `Observacoes` varchar(239) DEFAULT NULL,
  `DataBloqueio` varchar(10) DEFAULT NULL,
  `DataNeb` varchar(10) DEFAULT NULL,
  `Data1Sintomas` varchar(10) DEFAULT NULL,
  `Se1Sintomas` varchar(6) DEFAULT NULL,
  `DataColeta` varchar(13) DEFAULT NULL,
  `DataResultado` varchar(10) DEFAULT NULL,
  `Resultado` varchar(23) DEFAULT NULL,
  `ResultadoNs1` varchar(19) DEFAULT NULL,
  `AutoctoneImportado` varchar(12) DEFAULT NULL,
  `Fechamento` varchar(10) DEFAULT NULL,
  `LPICidade` varchar(12) DEFAULT NULL,
  `LpiEstado` varchar(12) DEFAULT NULL,
  `DataNotificacao` varchar(10) DEFAULT NULL,
  `UnidadeNotificadora` varchar(60) DEFAULT NULL,
  `SeDataNotificacao` varchar(6) DEFAULT NULL,
  `usuarioExame` varchar(13) DEFAULT NULL,
  `DataAlteracaoExame` varchar(10) DEFAULT NULL,
  `usuarioAlteracao` varchar(13) DEFAULT NULL,
  `DataAlteracao` datetime DEFAULT current_timestamp(),
  `Sexo` varchar(1) DEFAULT NULL,
  `DataNascimento` varchar(10) DEFAULT NULL,
  `usuarioLer` varchar(13) DEFAULT NULL,
  `DataLer` varchar(19) DEFAULT NULL,
  `Impressao` varchar(2) DEFAULT '0',
  `DataObito` varchar(10) DEFAULT NULL,
  `CnesUnidadeNotificadora` varchar(7) DEFAULT NULL,
  `Latitude` varchar(10) DEFAULT NULL,
  `Longitude` varchar(19) DEFAULT NULL,
  `RuaGoogle` varchar(103) DEFAULT NULL,
  `Status` varchar(10) DEFAULT NULL,
  `Descarte` varchar(2) DEFAULT '0',
  `idRua` varchar(4) DEFAULT NULL,
  `agravo` varchar(20) NOT NULL DEFAULT 'LEPTOSPIROSE',
  `ResultadoTr` varchar(20) NOT NULL DEFAULT 'Exame Nao Realizado'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `tbllepto`
--

INSERT INTO `tbllepto` (`DataEntrada`, `nDoc`, `NomeSolicitante`, `TelefoneFixo`, `Ddd`, `Da`, `Setor1`, `Cep1`, `Logradouro`, `Endereco1`, `N`, `Complemento`, `Bairro1`, `UBS1`, `PgGuia1`, `Observacoes`, `DataBloqueio`, `DataNeb`, `Data1Sintomas`, `Se1Sintomas`, `DataColeta`, `DataResultado`, `Resultado`, `ResultadoNs1`, `AutoctoneImportado`, `Fechamento`, `LPICidade`, `LpiEstado`, `DataNotificacao`, `UnidadeNotificadora`, `SeDataNotificacao`, `usuarioExame`, `DataAlteracaoExame`, `usuarioAlteracao`, `DataAlteracao`, `Sexo`, `DataNascimento`, `usuarioLer`, `DataLer`, `Impressao`, `DataObito`, `CnesUnidadeNotificadora`, `Latitude`, `Longitude`, `RuaGoogle`, `Status`, `Descarte`, `idRua`, `agravo`, `ResultadoTr`) VALUES
('28/01/2022', '7267348', 'JAIME CRISTINO', '910042396', '11', '83', '8306', '02372-140', 'ALAMEDA', 'FIGUEIRAS, DAS ( RUA PEDRO MARQUES )', '30', '', 'TREMEMBE', 'UBS J FONTALIS', '', NULL, NULL, NULL, '04/01/2022', '202201', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '12/01/2022', 'HOSP MUN DR IGNACIO PROENCA DE GOUVEA', '202202', NULL, NULL, 'D790072', '2022-01-28 08:02:08', NULL, '21/10/1961', NULL, NULL, '0', NULL, '2084473', '-23.443236', '-46.57863739999999', 'Rua Alameda das Figueiras, 30 - Jardim Joana D\'arc, São Paulo - SP, Brasil', NULL, '0', '701', 'LEPTOSPIROSE', 'Exame Nao Realizado'),
('29/08/2022', '7288637', 'CARLOS EDUARDO SILVA', '972972284', '11', '38', '0', '02237-055', 'RUA', 'PAZ DO NILO', '185', 'DBTB', 'JARDIM MODELO', 'UBS PQ EDU CHAVES', 'A00-A00', NULL, NULL, NULL, '10/07/2022', '202228', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '25/07/2022', 'HOSP SAO LUIZ GONZAGA', '202230', NULL, NULL, 'D790072', '2022-08-29 10:28:53', NULL, '12/02/1990', NULL, NULL, '0', NULL, '2076896', '-23.462236', '-46.57033089999999', 'Rua da Paz - Jardim Modelo, São Paulo - SP, Brasil', NULL, '0', '1833', 'LEPTOSPIROSE', 'Exame Nao Realizado'),
('17/02/2022', '7288715', 'FRANCISCA BENEDITA VIEIRA SILVA', '94017892', '11', '83', '8303', '02323-000', 'RUA', 'USHIKICHI KAMIYA (DO N 520 ATE 1060 LADO PAR E IMPAR)', '10', '', 'JARDIM FONTALIS', 'UBS J FONTALIS', '15-S03', NULL, NULL, NULL, '27/01/2022', '202204', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '07/02/2022', 'HOSP SAO LUIZ GONZAGA', '202206', NULL, NULL, 'D790072', '2022-02-17 09:43:24', NULL, '15/10/1965', NULL, NULL, '0', NULL, '2076896', '-23.443010', '-46.5942649', 'Rua Ushikichi Kamiya, 10 - Jardim Fontalis, São Paulo - SP, 02323-000, Brazil', NULL, '0', '1763', 'LEPTOSPIROSE', 'Exame Nao Realizado'),
('11/03/2022', '7288738', 'LUAN ROBERO DORTA', '963690696', '11', '38', '3814', '02237-045', 'RUA', 'FLORES DO NILO', '01', '', 'JARDIM MODELO', 'UBS PQ EDU CHAVES', '043X11', NULL, NULL, NULL, '28/02/2022', '202209', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '08/03/2022', 'HOSP SAO LUIZ GONZAGA', '202210', NULL, NULL, 'D788796', '2022-03-11 11:38:02', NULL, '10/06/1998', NULL, NULL, '0', NULL, '2076896', '-23.463044', '-46.57076929999999', 'Rua Flores do Nilo, 1 - Jardim Modelo, São Paulo - SP, Brasil', NULL, '0', '716', 'LEPTOSPIROSE', 'Exame Nao Realizado'),
('17/03/2022', '8685207', 'CARLOS ANTONIO GOMES', '995602810', '11', '83', '8309', '02319-000', 'AVENIDA', 'JOSINO VIEIRA DE GOES(PAR DO INICIO ATE 786)', '371', 'CASA', 'PQ. CASA DE PEDRA', 'UBS J JOAMAR', '14-E20', NULL, NULL, NULL, '03/03/2022', '202209', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '11/03/2022', 'HOSP SAO LUIZ GONZAGA', '202210', NULL, NULL, 'D788796', '2022-03-17 08:31:41', NULL, '26/06/1965', NULL, NULL, '0', NULL, '2076896', '-23.450704', '-46.596069', 'Avenida Josino Vieira de Goes, 371 - Tremembé, São Paulo - SP, Brasil', NULL, '0', '1048', 'LEPTOSPIROSE', 'Exame Nao Realizado'),
('16/05/2022', '8685225', 'REGINALDO SILVA ALMEIDA', '943013551', '11', '83', '8306', '02365-000', 'ESTRADA', 'CACHOEIRA, DA', '698', 'DBTB', 'FURNAS', 'UBS J FONTALIS', '14-X02', NULL, NULL, NULL, '20/04/2022', '202216', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '06/05/2022', 'HOSP SAO LUIZ GONZAGA', '202218', NULL, NULL, 'D788796', '2022-05-16 08:34:12', NULL, '23/11/1971', NULL, NULL, '0', NULL, '2076896', '-23.433900', '-46.5836617', 'Estrada da Cachoeira, 698 - Furnas, São Paulo - SP, 02365-000, Brazil', NULL, '0', '426', 'LEPTOSPIROSE', 'Exame Nao Realizado'),
('11/03/2022', '8685272', 'ADEMAR AZEVEDO MAIA', '996057035', '11', '83', '8308', '02325-060', 'TRAVESSA', 'BARRA DO BARAO *', '85', '', 'JD. FILHOS DA TERRA', 'UBS J APUANA', '14-X25', NULL, NULL, NULL, '23/02/2022', '202208', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '05/03/2022', 'HOSP SAO LUIZ GONZAGA', '202209', NULL, NULL, 'D788796', '2022-03-11 11:38:21', NULL, '21/03/1959', NULL, NULL, '0', NULL, '2076896', '-23.453775', '-46.5853277', 'Travessa Barra do Barão, 85 - Jardim Filhos da Terra, São Paulo - SP, Brasil', NULL, '0', '324', 'LEPTOSPIROSE', 'Exame Nao Realizado'),
('16/05/2022', '8691456', 'CLEBIANO ARNEIRO DA CRUZ', '974626890', '11', '83', '8314', '02378-130', 'RUA', 'FRUTUOSO VIANNA', '355', '', 'CANTAREIRA', 'UBS DONA MARIQUINHA SCIASCIA', '12-F20', NULL, NULL, NULL, '25/04/2022', '202217', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '04/05/2022', 'HOSPITAL GERAL DE VILA NOVA CACHOEIRINHA SAO PAULO', '202218', NULL, NULL, 'D788796', '2022-05-16 08:33:44', NULL, '26/03/1984', NULL, NULL, '0', NULL, '2688573', '-23.449415', '-46.6299889', 'Rua Fructuoso Vianna, 355 - Horto Florestal, São Paulo - SP, Brasil', NULL, '0', '765', 'LEPTOSPIROSE', 'Exame Nao Realizado'),
('11/03/2022', '8726127', 'JOAO LOPES DE OLIVEIRA', '940885679', '11', '38', '3804', '02237-078', 'TRAVESSA', 'SAO JOSE DO NILO', '54', '', 'JARDIM MODELO', 'UBS PQ EDU CHAVES', '044A10', NULL, NULL, NULL, '20/02/2022', '202208', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '07/03/2022', 'HOSP MUN VER JOSE STOROPOLLI', '202210', NULL, NULL, 'D788796', '2022-03-11 11:36:53', NULL, '20/05/1978', NULL, NULL, '0', NULL, '3212130', '-23.462753', '-46.57036308650817', 'Rua da Paz - Jardim Modelo, São Paulo - SP, Brasil', NULL, '0', '1636', 'LEPTOSPIROSE', 'Exame Nao Realizado'),
('11/03/2022', '8728112', 'DEIVID FRANCISCO COSTA GOES', '992823624', '11', '83', '8301', '02364-590', 'RUA', 'ALZIRA MARIA DA SILVA', '83', '', 'JARDIM FONTALIS', 'UBS J FONTALIS', 'A80L29', NULL, NULL, NULL, '13/02/2022', '202207', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '24/02/2022', 'HOSPITAL ESTADUAL DE VILA ALPINA ORG SOCIAL SECONCI SAO PAUL', '202208', NULL, NULL, 'D788796', '2022-03-11 11:37:35', NULL, '29/04/1986', NULL, NULL, '0', NULL, '2077426', '-23.435229', '-46.57888200000001', 'Rua Alzira Maria da Silva, 83 - Jardim Fontalis, São Paulo - SP, Brasil', NULL, '0', '137', 'LEPTOSPIROSE', 'Exame Nao Realizado'),
('18/04/2022', '8728513', 'LUCAS DE SOUZA MARQUES', '967254741', '11', '38', '3809', '02226-000', 'RUA', 'SOTOMANO, TTE. (ATE N 400)', '46', '', 'JARDIM MODELO', 'UBS JACANA', '43-M22', NULL, NULL, NULL, '05/04/2022', '202214', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '06/04/2022', 'HOSP MUN DR IGNACIO PROENCA DE GOUVEA', '202214', NULL, NULL, 'D790072', '2022-04-18 09:34:16', NULL, '19/03/1988', NULL, NULL, '0', NULL, '2084473', '-23.471095', '-46.57864530000001', 'Rua Tenente Sotomano, 46 - Vila Sabrina, São Paulo - SP, Brasil', NULL, '0', '1694', 'LEPTOSPIROSE', 'Exame Nao Realizado'),
('29/08/2022', '8793796', 'FERNANDO DASILVA SANTOS', '945240184', '11', '83', '8317', '02306-004', 'AVENIDA', 'SEZEFREDO FAGUNDES, CEL. (1816 AO 3230 PAR)', 's/n', '', 'TREMEMBE', 'UBS J JOAMAR', '', NULL, NULL, NULL, '03/06/2022', '202222', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '21/06/2022', 'UBS INACIO MONTEIRO', '202225', NULL, NULL, 'D790072', '2022-08-29 10:27:54', NULL, '12/07/1989', NULL, NULL, '0', NULL, '3661660', '-23.411466', '-46.58189350000001', 'Avenida Coronel Sezefredo Fagundes - Sítio Barrocada, São Paulo - SP, Brasil', NULL, '0', '1674', 'LEPTOSPIROSE', 'Exame Nao Realizado'),
('29/08/2022', '8799078', 'ANDERSON FERREIRA DA SILVA', '971051062', '11', '83', '8316', '02357-060', 'RUA', 'ELIAS DE SOUSA PINTO', '81', 'CASA  15', 'JD. SANTA MARCELINA', 'UBS V ALBERTINA DR OSVALDO MARCAL', '13-E16', NULL, NULL, NULL, '09/07/2022', '202227', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '19/07/2022', 'HOSP METROPOLITANO', '202229', NULL, NULL, 'D790072', '2022-08-29 10:28:32', NULL, '25/02/1976', NULL, NULL, '0', NULL, '2078082', '-23.448781', '-46.6132194', 'Rua Elias de Sousa Pinto, 81 - Tremembé, São Paulo - SP, 02357-060, Brazil', NULL, '0', '628', 'LEPTOSPIROSE', 'Exame Nao Realizado'),
('29/08/2022', '8853368', 'WILSON ROBERTO CAMILLO', '983929534', '11', '83', '8313', '02374-020', 'RUA', 'ANTONINHO MARMO', '85', '', 'VILA IRMAOS ARNONI', 'UBS DONA MARIQUINHA SCIASCIA', '12-S23', NULL, NULL, NULL, '08/07/2022', '202227', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '19/07/2022', 'HOSP MUN VER JOSE STOROPOLLI', '202229', NULL, NULL, 'D790072', '2022-08-29 10:28:09', NULL, '23/03/1958', NULL, NULL, '0', NULL, '3212130', '-23.456447', '-46.62251759999999', 'Rua Antoninho Marmo, 85 - Vila Irmaos Arnoni, São Paulo - SP, 02374-020, Brazil', NULL, '0', '192', 'LEPTOSPIROSE', 'Exame Nao Realizado');
