
--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `adm_sanitaria`
--
ALTER TABLE `adm_sanitaria`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `agravo`
--
ALTER TABLE `agravo`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `anos`
--
ALTER TABLE `anos`
  ADD PRIMARY KEY (`id_anos`);

--
-- Índices para tabela `antranet`
--
ALTER TABLE `antranet`
  ADD PRIMARY KEY (`NU_NOTIFIC`);

--
-- Índices para tabela `assuntotid`
--
ALTER TABLE `assuntotid`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `cargo`
--
ALTER TABLE `cargo`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `chikonnet`
--
ALTER TABLE `chikonnet`
  ADD PRIMARY KEY (`NU_NOTIFIC`);

--
-- Índices para tabela `chiku_ial`
--
ALTER TABLE `chiku_ial`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `cidade`
--
ALTER TABLE `cidade`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `cod_cidade` (`cod_cidade`);

--
-- Índices para tabela `cnes`
--
ALTER TABLE `cnes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `cnes` (`cnes`);

--
-- Índices para tabela `config_system`
--
ALTER TABLE `config_system`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `control_dig_cad`
--
ALTER TABLE `control_dig_cad`
  ADD PRIMARY KEY (`id_control`);

--
-- Índices para tabela `coquenet`
--
ALTER TABLE `coquenet`
  ADD PRIMARY KEY (`NU_NOTIFIC`);

--
-- Índices para tabela `coquenet_2021`
--
ALTER TABLE `coquenet_2021`
  ADD PRIMARY KEY (`NU_NOTIFIC`);

--
-- Índices para tabela `coque_ial`
--
ALTER TABLE `coque_ial`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `da`
--
ALTER TABLE `da`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `dengnet`
--
ALTER TABLE `dengnet`
  ADD PRIMARY KEY (`NU_NOTIFIC`);

--
-- Índices para tabela `dengue_ial`
--
ALTER TABLE `dengue_ial`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `doenca`
--
ALTER TABLE `doenca`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `doencasiva`
--
ALTER TABLE `doencasiva`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `doencasurto`
--
ALTER TABLE `doencasurto`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `emitentetid`
--
ALTER TABLE `emitentetid`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `especie_animal`
--
ALTER TABLE `especie_animal`
  ADD PRIMARY KEY (`id_especie`);

--
-- Índices para tabela `espe_pe_ie`
--
ALTER TABLE `espe_pe_ie`
  ADD PRIMARY KEY (`id_esp_pe_ie`);

--
-- Índices para tabela `esporo_an`
--
ALTER TABLE `esporo_an`
  ADD PRIMARY KEY (`id_esp`);

--
-- Índices para tabela `esporo_an_051022`
--
ALTER TABLE `esporo_an_051022`
  ADD PRIMARY KEY (`id_esp`);

--
-- Índices para tabela `esporo_an_051022_1`
--
ALTER TABLE `esporo_an_051022_1`
  ADD PRIMARY KEY (`id_esp`);

--
-- Índices para tabela `esporo_an_e`
--
ALTER TABLE `esporo_an_e`
  ADD PRIMARY KEY (`id_esp`);

--
-- Índices para tabela `esporo_an_ent_medc`
--
ALTER TABLE `esporo_an_ent_medc`
  ADD PRIMARY KEY (`id_esp_ent`);

--
-- Índices para tabela `esporo_an_sd_medc`
--
ALTER TABLE `esporo_an_sd_medc`
  ADD PRIMARY KEY (`id_sd`);

--
-- Índices para tabela `esporo_an_sd_medc_200922`
--
ALTER TABLE `esporo_an_sd_medc_200922`
  ADD PRIMARY KEY (`id_sd`);

--
-- Índices para tabela `esporo_medc`
--
ALTER TABLE `esporo_medc`
  ADD PRIMARY KEY (`id_med_esp`);

--
-- Índices para tabela `esporo_medc_erro`
--
ALTER TABLE `esporo_medc_erro`
  ADD PRIMARY KEY (`id_rem`);

--
-- Índices para tabela `estabelecimentos`
--
ALTER TABLE `estabelecimentos`
  ADD PRIMARY KEY (`cpf_cnpj_est`);

--
-- Índices para tabela `esus_covisa`
--
ALTER TABLE `esus_covisa`
  ADD PRIMARY KEY (`NU_NOTIFIC`);

--
-- Índices para tabela `esus_covisa_2022_270522`
--
ALTER TABLE `esus_covisa_2022_270522`
  ADD PRIMARY KEY (`NU_NOTIFIC`);

--
-- Índices para tabela `exantnet`
--
ALTER TABLE `exantnet`
  ADD PRIMARY KEY (`NU_NOTIFIC`);

--
-- Índices para tabela `exantnet_2021`
--
ALTER TABLE `exantnet_2021`
  ADD PRIMARY KEY (`NU_NOTIFIC`);

--
-- Índices para tabela `famarnet`
--
ALTER TABLE `famarnet`
  ADD PRIMARY KEY (`NU_NOTIFIC`);

--
-- Índices para tabela `famarnet_2021`
--
ALTER TABLE `famarnet_2021`
  ADD PRIMARY KEY (`NU_NOTIFIC`);

--
-- Índices para tabela `febrea_ial`
--
ALTER TABLE `febrea_ial`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `footer`
--
ALTER TABLE `footer`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `idade`
--
ALTER TABLE `idade`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `idadesv2`
--
ALTER TABLE `idadesv2`
  ADD PRIMARY KEY (`id_sv2_idade`);

--
-- Índices para tabela `index_config`
--
ALTER TABLE `index_config`
  ADD PRIMARY KEY (`id_index`);

--
-- Índices para tabela `leptonet`
--
ALTER TABLE `leptonet`
  ADD PRIMARY KEY (`NU_NOTIFIC`);

--
-- Índices para tabela `leptonet_2021`
--
ALTER TABLE `leptonet_2021`
  ADD PRIMARY KEY (`NU_NOTIFIC`);

--
-- Índices para tabela `logradouro`
--
ALTER TABLE `logradouro`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `materiais_controle`
--
ALTER TABLE `materiais_controle`
  ADD PRIMARY KEY (`id_controle`);

--
-- Índices para tabela `materiais_controles`
--
ALTER TABLE `materiais_controles`
  ADD PRIMARY KEY (`id_controle`);

--
-- Índices para tabela `memo`
--
ALTER TABLE `memo`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `memo_2017`
--
ALTER TABLE `memo_2017`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `memo_2018`
--
ALTER TABLE `memo_2018`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `memo_2019`
--
ALTER TABLE `memo_2019`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `memo_2020`
--
ALTER TABLE `memo_2020`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `memo_2021`
--
ALTER TABLE `memo_2021`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `menu_principal`
--
ALTER TABLE `menu_principal`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `menu_sub`
--
ALTER TABLE `menu_sub`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `menu_sub_jt`
--
ALTER TABLE `menu_sub_jt`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `menu_sub_sub`
--
ALTER TABLE `menu_sub_sub`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `menu_sub_sub_jt`
--
ALTER TABLE `menu_sub_sub_jt`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `ocorrenciasurto`
--
ALTER TABLE `ocorrenciasurto`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `orgao`
--
ALTER TABLE `orgao`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `origem`
--
ALTER TABLE `origem`
  ADD PRIMARY KEY (`id_origem`);

--
-- Índices para tabela `pag_admin`
--
ALTER TABLE `pag_admin`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `pag_system`
--
ALTER TABLE `pag_system`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `pes_ies_38_83`
--
ALTER TABLE `pes_ies_38_83`
  ADD PRIMARY KEY (`id_pe_ie`);

--
-- Índices para tabela `resultado_ccz`
--
ALTER TABLE `resultado_ccz`
  ADD PRIMARY KEY (`PEDIDO`);

--
-- Índices para tabela `resultado_ccz_2021`
--
ALTER TABLE `resultado_ccz_2021`
  ADD PRIMARY KEY (`PEDIDO`);

--
-- Índices para tabela `resultado_ccz_2022`
--
ALTER TABLE `resultado_ccz_2022`
  ADD PRIMARY KEY (`PEDIDO`);

--
-- Índices para tabela `resultado_ccz_lepto`
--
ALTER TABLE `resultado_ccz_lepto`
  ADD PRIMARY KEY (`PEDIDO`);

--
-- Índices para tabela `resultado_ccz_lepto_2021`
--
ALTER TABLE `resultado_ccz_lepto_2021`
  ADD PRIMARY KEY (`PEDIDO`);

--
-- Índices para tabela `resultado_ccz_lepto_2022`
--
ALTER TABLE `resultado_ccz_lepto_2022`
  ADD PRIMARY KEY (`PEDIDO`);

--
-- Índices para tabela `resultado_esporo`
--
ALTER TABLE `resultado_esporo`
  ADD PRIMARY KEY (`Nr_Pedido`);

--
-- Índices para tabela `ruas`
--
ALTER TABLE `ruas`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `ruas1`
--
ALTER TABLE `ruas1`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `ruas_backup`
--
ALTER TABLE `ruas_backup`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `ruas_backup_31032022`
--
ALTER TABLE `ruas_backup_31032022`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `ruas_jacana_cep_esus`
--
ALTER TABLE `ruas_jacana_cep_esus`
  ADD PRIMARY KEY (`cep`);

--
-- Índices para tabela `sarampo_ial`
--
ALTER TABLE `sarampo_ial`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `sarampo_ial_2021`
--
ALTER TABLE `sarampo_ial_2021`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `se`
--
ALTER TABLE `se`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `se2020`
--
ALTER TABLE `se2020`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `sexo`
--
ALTER TABLE `sexo`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `sisdamoptions`
--
ALTER TABLE `sisdamoptions`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`);

--
-- Índices para tabela `situacao_esporo`
--
ALTER TABLE `situacao_esporo`
  ADD PRIMARY KEY (`id_st_esp`);

--
-- Índices para tabela `siva`
--
ALTER TABLE `siva`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `suvis`
--
ALTER TABLE `suvis`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `sv2`
--
ALTER TABLE `sv2`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `sv2_2016`
--
ALTER TABLE `sv2_2016`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `sv2_2017`
--
ALTER TABLE `sv2_2017`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `sv2_2018`
--
ALTER TABLE `sv2_2018`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `sv2_2019`
--
ALTER TABLE `sv2_2019`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `sv2_2020`
--
ALTER TABLE `sv2_2020`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `sv2_2021`
--
ALTER TABLE `sv2_2021`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `sv2_2909`
--
ALTER TABLE `sv2_2909`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `sv2_backup_300522`
--
ALTER TABLE `sv2_backup_300522`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `sv2_backup_310522`
--
ALTER TABLE `sv2_backup_310522`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `sv2_novo`
--
ALTER TABLE `sv2_novo`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `sv2_violencia_2020_uvis_final`
--
ALTER TABLE `sv2_violencia_2020_uvis_final`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `tblantrab`
--
ALTER TABLE `tblantrab`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `tblchiku`
--
ALTER TABLE `tblchiku`
  ADD PRIMARY KEY (`NomeSolicitante`);

--
-- Índices para tabela `tblchiku_2020`
--
ALTER TABLE `tblchiku_2020`
  ADD PRIMARY KEY (`NomeSolicitante`);

--
-- Índices para tabela `tblchiku_2021`
--
ALTER TABLE `tblchiku_2021`
  ADD PRIMARY KEY (`NomeSolicitante`);

--
-- Índices para tabela `tbldengue`
--
ALTER TABLE `tbldengue`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `tbldengue_2020`
--
ALTER TABLE `tbldengue_2020`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `tbldengue_2021`
--
ALTER TABLE `tbldengue_2021`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `tblfebrea`
--
ALTER TABLE `tblfebrea`
  ADD PRIMARY KEY (`NomeSolicitante`);

--
-- Índices para tabela `tblfebrea_2020`
--
ALTER TABLE `tblfebrea_2020`
  ADD PRIMARY KEY (`NomeSolicitante`);

--
-- Índices para tabela `tblfebrea_2021`
--
ALTER TABLE `tblfebrea_2021`
  ADD PRIMARY KEY (`NomeSolicitante`);

--
-- Índices para tabela `tbllepto`
--
ALTER TABLE `tbllepto`
  ADD PRIMARY KEY (`nDoc`);

--
-- Índices para tabela `tbllepto_2020`
--
ALTER TABLE `tbllepto_2020`
  ADD PRIMARY KEY (`nDoc`);

--
-- Índices para tabela `tbllepto_2021`
--
ALTER TABLE `tbllepto_2021`
  ADD PRIMARY KEY (`nDoc`);

--
-- Índices para tabela `tblsarampo`
--
ALTER TABLE `tblsarampo`
  ADD PRIMARY KEY (`nDoc`);

--
-- Índices para tabela `tblsarampo_2020`
--
ALTER TABLE `tblsarampo_2020`
  ADD PRIMARY KEY (`nDoc`);

--
-- Índices para tabela `tblsarampo_2021`
--
ALTER TABLE `tblsarampo_2021`
  ADD PRIMARY KEY (`nDoc`);

--
-- Índices para tabela `unidade`
--
ALTER TABLE `unidade`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `usuarios_oki`
--
ALTER TABLE `usuarios_oki`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `zika_ial`
--
ALTER TABLE `zika_ial`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `adm_sanitaria`
--
ALTER TABLE `adm_sanitaria`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=174;

--
-- AUTO_INCREMENT de tabela `agravo`
--
ALTER TABLE `agravo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=156;

--
-- AUTO_INCREMENT de tabela `anos`
--
ALTER TABLE `anos`
  MODIFY `id_anos` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=201;

--
-- AUTO_INCREMENT de tabela `assuntotid`
--
ALTER TABLE `assuntotid`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1274;

--
-- AUTO_INCREMENT de tabela `cargo`
--
ALTER TABLE `cargo`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de tabela `chiku_ial`
--
ALTER TABLE `chiku_ial`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;

--
-- AUTO_INCREMENT de tabela `cidade`
--
ALTER TABLE `cidade`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5855;

--
-- AUTO_INCREMENT de tabela `cnes`
--
ALTER TABLE `cnes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2195;

--
-- AUTO_INCREMENT de tabela `config_system`
--
ALTER TABLE `config_system`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `control_dig_cad`
--
ALTER TABLE `control_dig_cad`
  MODIFY `id_control` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `coque_ial`
--
ALTER TABLE `coque_ial`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de tabela `da`
--
ALTER TABLE `da`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT de tabela `dengue_ial`
--
ALTER TABLE `dengue_ial`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65984;

--
-- AUTO_INCREMENT de tabela `doenca`
--
ALTER TABLE `doenca`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=142;

--
-- AUTO_INCREMENT de tabela `doencasiva`
--
ALTER TABLE `doencasiva`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `doencasurto`
--
ALTER TABLE `doencasurto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT de tabela `emitentetid`
--
ALTER TABLE `emitentetid`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6692;

--
-- AUTO_INCREMENT de tabela `especie_animal`
--
ALTER TABLE `especie_animal`
  MODIFY `id_especie` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `espe_pe_ie`
--
ALTER TABLE `espe_pe_ie`
  MODIFY `id_esp_pe_ie` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT de tabela `esporo_an`
--
ALTER TABLE `esporo_an`
  MODIFY `id_esp` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=167;

--
-- AUTO_INCREMENT de tabela `esporo_an_051022`
--
ALTER TABLE `esporo_an_051022`
  MODIFY `id_esp` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=167;

--
-- AUTO_INCREMENT de tabela `esporo_an_051022_1`
--
ALTER TABLE `esporo_an_051022_1`
  MODIFY `id_esp` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=167;

--
-- AUTO_INCREMENT de tabela `esporo_an_e`
--
ALTER TABLE `esporo_an_e`
  MODIFY `id_esp` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=168;

--
-- AUTO_INCREMENT de tabela `esporo_an_ent_medc`
--
ALTER TABLE `esporo_an_ent_medc`
  MODIFY `id_esp_ent` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `esporo_an_sd_medc`
--
ALTER TABLE `esporo_an_sd_medc`
  MODIFY `id_sd` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=162;

--
-- AUTO_INCREMENT de tabela `esporo_an_sd_medc_200922`
--
ALTER TABLE `esporo_an_sd_medc_200922`
  MODIFY `id_sd` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=161;

--
-- AUTO_INCREMENT de tabela `esporo_medc`
--
ALTER TABLE `esporo_medc`
  MODIFY `id_med_esp` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `esporo_medc_erro`
--
ALTER TABLE `esporo_medc_erro`
  MODIFY `id_rem` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=291;

--
-- AUTO_INCREMENT de tabela `febrea_ial`
--
ALTER TABLE `febrea_ial`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=518;

--
-- AUTO_INCREMENT de tabela `footer`
--
ALTER TABLE `footer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `idade`
--
ALTER TABLE `idade`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=175;

--
-- AUTO_INCREMENT de tabela `idadesv2`
--
ALTER TABLE `idadesv2`
  MODIFY `id_sv2_idade` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=112;

--
-- AUTO_INCREMENT de tabela `index_config`
--
ALTER TABLE `index_config`
  MODIFY `id_index` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `logradouro`
--
ALTER TABLE `logradouro`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=128;

--
-- AUTO_INCREMENT de tabela `materiais_controle`
--
ALTER TABLE `materiais_controle`
  MODIFY `id_controle` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=106;

--
-- AUTO_INCREMENT de tabela `materiais_controles`
--
ALTER TABLE `materiais_controles`
  MODIFY `id_controle` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `memo`
--
ALTER TABLE `memo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=140;

--
-- AUTO_INCREMENT de tabela `memo_2017`
--
ALTER TABLE `memo_2017`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=389;

--
-- AUTO_INCREMENT de tabela `memo_2018`
--
ALTER TABLE `memo_2018`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=333;

--
-- AUTO_INCREMENT de tabela `memo_2019`
--
ALTER TABLE `memo_2019`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=288;

--
-- AUTO_INCREMENT de tabela `memo_2020`
--
ALTER TABLE `memo_2020`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=272;

--
-- AUTO_INCREMENT de tabela `memo_2021`
--
ALTER TABLE `memo_2021`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=172;

--
-- AUTO_INCREMENT de tabela `menu_principal`
--
ALTER TABLE `menu_principal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de tabela `menu_sub`
--
ALTER TABLE `menu_sub`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT de tabela `menu_sub_jt`
--
ALTER TABLE `menu_sub_jt`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT de tabela `menu_sub_sub`
--
ALTER TABLE `menu_sub_sub`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=113;

--
-- AUTO_INCREMENT de tabela `menu_sub_sub_jt`
--
ALTER TABLE `menu_sub_sub_jt`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;

--
-- AUTO_INCREMENT de tabela `ocorrenciasurto`
--
ALTER TABLE `ocorrenciasurto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de tabela `orgao`
--
ALTER TABLE `orgao`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT de tabela `origem`
--
ALTER TABLE `origem`
  MODIFY `id_origem` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `pag_admin`
--
ALTER TABLE `pag_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT de tabela `pag_system`
--
ALTER TABLE `pag_system`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=157;

--
-- AUTO_INCREMENT de tabela `pes_ies_38_83`
--
ALTER TABLE `pes_ies_38_83`
  MODIFY `id_pe_ie` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=148;

--
-- AUTO_INCREMENT de tabela `ruas`
--
ALTER TABLE `ruas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1967;

--
-- AUTO_INCREMENT de tabela `ruas_backup`
--
ALTER TABLE `ruas_backup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1961;

--
-- AUTO_INCREMENT de tabela `ruas_backup_31032022`
--
ALTER TABLE `ruas_backup_31032022`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1845;

--
-- AUTO_INCREMENT de tabela `sarampo_ial`
--
ALTER TABLE `sarampo_ial`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1238;

--
-- AUTO_INCREMENT de tabela `sarampo_ial_2021`
--
ALTER TABLE `sarampo_ial_2021`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1238;

--
-- AUTO_INCREMENT de tabela `se`
--
ALTER TABLE `se`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2927;

--
-- AUTO_INCREMENT de tabela `se2020`
--
ALTER TABLE `se2020`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1833;

--
-- AUTO_INCREMENT de tabela `sexo`
--
ALTER TABLE `sexo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `sisdamoptions`
--
ALTER TABLE `sisdamoptions`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=590;

--
-- AUTO_INCREMENT de tabela `situacao_esporo`
--
ALTER TABLE `situacao_esporo`
  MODIFY `id_st_esp` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de tabela `siva`
--
ALTER TABLE `siva`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `suvis`
--
ALTER TABLE `suvis`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT de tabela `sv2`
--
ALTER TABLE `sv2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63133;

--
-- AUTO_INCREMENT de tabela `sv2_2016`
--
ALTER TABLE `sv2_2016`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=836;

--
-- AUTO_INCREMENT de tabela `sv2_2017`
--
ALTER TABLE `sv2_2017`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5416;

--
-- AUTO_INCREMENT de tabela `sv2_2018`
--
ALTER TABLE `sv2_2018`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5269;

--
-- AUTO_INCREMENT de tabela `sv2_2019`
--
ALTER TABLE `sv2_2019`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8008;

--
-- AUTO_INCREMENT de tabela `sv2_2020`
--
ALTER TABLE `sv2_2020`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76254;

--
-- AUTO_INCREMENT de tabela `sv2_2021`
--
ALTER TABLE `sv2_2021`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=212536;

--
-- AUTO_INCREMENT de tabela `sv2_2909`
--
ALTER TABLE `sv2_2909`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40246;

--
-- AUTO_INCREMENT de tabela `sv2_backup_300522`
--
ALTER TABLE `sv2_backup_300522`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13375;

--
-- AUTO_INCREMENT de tabela `sv2_backup_310522`
--
ALTER TABLE `sv2_backup_310522`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19545;

--
-- AUTO_INCREMENT de tabela `sv2_novo`
--
ALTER TABLE `sv2_novo`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=113;

--
-- AUTO_INCREMENT de tabela `sv2_violencia_2020_uvis_final`
--
ALTER TABLE `sv2_violencia_2020_uvis_final`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=947;

--
-- AUTO_INCREMENT de tabela `tblantrab`
--
ALTER TABLE `tblantrab`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `tbldengue`
--
ALTER TABLE `tbldengue`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1178;

--
-- AUTO_INCREMENT de tabela `tbldengue_2020`
--
ALTER TABLE `tbldengue_2020`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=692;

--
-- AUTO_INCREMENT de tabela `tbldengue_2021`
--
ALTER TABLE `tbldengue_2021`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=994;

--
-- AUTO_INCREMENT de tabela `unidade`
--
ALTER TABLE `unidade`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9929;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=137;

--
-- AUTO_INCREMENT de tabela `usuarios_oki`
--
ALTER TABLE `usuarios_oki`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=128;

--
-- AUTO_INCREMENT de tabela `zika_ial`
--
ALTER TABLE `zika_ial`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4499;
