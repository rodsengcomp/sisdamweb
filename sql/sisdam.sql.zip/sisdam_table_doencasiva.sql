
-- --------------------------------------------------------

--
-- Estrutura da tabela `doencasiva`
--

CREATE TABLE `doencasiva` (
  `id` int(11) NOT NULL,
  `doencanot` varchar(40) DEFAULT NULL,
  `cid` varchar(11) DEFAULT NULL,
  `criado` datetime DEFAULT NULL,
  `usuariocad` varchar(20) DEFAULT 'sistema',
  `alterado` datetime DEFAULT NULL,
  `usuarioalt` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `doencasiva`
--

INSERT INTO `doencasiva` (`id`, `doencanot`, `cid`, `criado`, `usuariocad`, `alterado`, `usuarioalt`) VALUES
(1, 'ACIDENTE DE TRANSITO (SIVA)', NULL, NULL, 'sistema', NULL, NULL),
(2, 'OUTROS ACIDENTES (SIVA)', NULL, NULL, 'sistema', NULL, NULL),
(3, 'EVENTOS ADVERSOS', NULL, NULL, 'sistema', NULL, NULL),
(4, 'ERROS DE IMUNIZACAO', NULL, NULL, 'sistema', NULL, NULL);
