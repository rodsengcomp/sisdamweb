
-- --------------------------------------------------------

--
-- Estrutura da tabela `materiais_controles`
--

CREATE TABLE `materiais_controles` (
  `id_controle` int(11) NOT NULL,
  `material` varchar(100) DEFAULT NULL,
  `qtd` int(10) DEFAULT NULL,
  `entrada` date DEFAULT NULL,
  `saida` date DEFAULT NULL,
  `n_memo` varchar(100) DEFAULT NULL,
  `obs` varchar(400) DEFAULT NULL,
  `nome_lib` varchar(50) DEFAULT NULL,
  `rf_lib` int(7) DEFAULT NULL,
  `nome_ret` varchar(50) DEFAULT NULL,
  `rf_ret` int(7) DEFAULT NULL,
  `usuariocad` varchar(20) DEFAULT 'sistema',
  `criado` datetime NOT NULL DEFAULT '2018-08-02 13:43:48',
  `usuarioalt` varchar(20) DEFAULT NULL,
  `alterado` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
