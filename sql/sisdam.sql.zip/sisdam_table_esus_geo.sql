
-- --------------------------------------------------------

--
-- Estrutura da tabela `esus_geo`
--

CREATE TABLE `esus_geo` (
  `NU_NOTIFIC` bigint(13) DEFAULT NULL,
  `NU_CEP` varchar(10) DEFAULT NULL,
  `LATSIRGAS` varchar(10) DEFAULT NULL,
  `LONSIRGAS` varchar(10) DEFAULT NULL,
  `COD_DISTRI` int(2) DEFAULT NULL,
  `CNES` int(7) DEFAULT NULL,
  `NOMEUBS` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
