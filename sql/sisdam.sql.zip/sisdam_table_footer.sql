
-- --------------------------------------------------------

--
-- Estrutura da tabela `footer`
--

CREATE TABLE `footer` (
  `id` int(11) NOT NULL,
  `sistema` varchar(200) DEFAULT NULL,
  `versao` varchar(50) DEFAULT NULL,
  `direitos` varchar(200) DEFAULT NULL,
  `desenvolvedor` varchar(200) DEFAULT NULL,
  `email_contato` varchar(100) DEFAULT NULL,
  `ano` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `footer`
--

INSERT INTO `footer` (`id`, `sistema`, `versao`, `direitos`, `desenvolvedor`, `email_contato`, `ano`) VALUES
(1, 'Sisdam Web', '1.9', 'Todos os direitos reservados', 'Rodolfo R R de Jesus', 'sisdamjt@gmail.com', 2013);
