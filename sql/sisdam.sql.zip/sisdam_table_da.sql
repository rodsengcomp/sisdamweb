
-- --------------------------------------------------------

--
-- Estrutura da tabela `da`
--

CREATE TABLE `da` (
  `id` int(11) NOT NULL,
  `da` varchar(2) NOT NULL,
  `setor` varchar(4) NOT NULL,
  `uvis` int(11) NOT NULL,
  `criado` datetime DEFAULT NULL,
  `usuariocad` varchar(20) DEFAULT NULL,
  `alterado` datetime DEFAULT NULL,
  `usuarioalt` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `da`
--

INSERT INTO `da` (`id`, `da`, `setor`, `uvis`, `criado`, `usuariocad`, `alterado`, `usuarioalt`) VALUES
(1, '38', '3800', 0, NULL, NULL, NULL, NULL),
(2, '38', '3801', 0, NULL, NULL, NULL, NULL),
(3, '38', '3802', 0, NULL, NULL, NULL, NULL),
(4, '38', '3803', 0, NULL, NULL, NULL, NULL),
(5, '38', '3804', 0, NULL, NULL, NULL, NULL),
(6, '38', '3805', 0, NULL, NULL, NULL, NULL),
(7, '38', '3806', 0, NULL, NULL, NULL, NULL),
(8, '38', '3807', 0, NULL, NULL, NULL, NULL),
(9, '38', '3808', 0, NULL, NULL, NULL, NULL),
(10, '38', '3809', 0, NULL, NULL, NULL, NULL),
(11, '38', '3810', 0, NULL, NULL, NULL, NULL),
(12, '38', '3811', 0, NULL, NULL, NULL, NULL),
(13, '38', '3812', 0, NULL, NULL, NULL, NULL),
(14, '38', '3813', 0, NULL, NULL, NULL, NULL),
(15, '38', '3814', 0, NULL, NULL, NULL, NULL),
(16, '83', '8300', 0, NULL, NULL, NULL, NULL),
(17, '83', '8301', 0, NULL, NULL, NULL, NULL),
(18, '83', '8302', 0, NULL, NULL, NULL, NULL),
(19, '83', '8303', 0, NULL, NULL, NULL, NULL),
(20, '83', '8304', 0, NULL, NULL, NULL, NULL),
(21, '83', '8305', 0, NULL, NULL, NULL, NULL),
(22, '83', '8306', 0, NULL, NULL, NULL, NULL),
(23, '83', '8307', 0, NULL, NULL, NULL, NULL),
(24, '83', '8308', 0, NULL, NULL, NULL, NULL),
(25, '83', '8309', 0, NULL, NULL, NULL, NULL),
(26, '83', '8310', 0, NULL, NULL, NULL, NULL),
(27, '83', '8311', 0, NULL, NULL, NULL, NULL),
(28, '83', '8312', 0, NULL, NULL, NULL, NULL),
(29, '83', '8313', 0, NULL, NULL, NULL, NULL),
(30, '83', '8314', 0, NULL, NULL, NULL, NULL),
(31, '83', '8315', 0, NULL, NULL, NULL, NULL),
(32, '83', '8316', 0, NULL, NULL, NULL, NULL),
(33, '83', '8317', 0, NULL, NULL, NULL, NULL),
(34, '83', '8318', 0, NULL, NULL, NULL, NULL),
(35, '83', '8319', 0, NULL, NULL, NULL, NULL),
(36, '83', '8320', 0, NULL, NULL, NULL, NULL),
(37, '38', '3838', 0, NULL, NULL, NULL, NULL),
(38, '83', '8383', 0, NULL, NULL, NULL, NULL),
(39, '00', '0000', 0, NULL, NULL, NULL, NULL);
